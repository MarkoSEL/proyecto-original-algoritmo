package HuellaEstudiantil.datos;

import HuellaEstudiantil.modelo.*;

public class BaseDeDatos {

    private static BaseDeDatos instancia;

    public ListaEstudiante listaEstudiantes;
    public ListaCurso listaCursos;
    public ListaDocente listaDocentes;
    public ListaSeccion listaSecciones;
    public ListaPeriodo listaPeriodos;
    // Nota: Los HashSet de control se eliminaron, ahora se valida contra las listas.
    
    private BaseDeDatos() {
        listaEstudiantes = new ListaEstudiante();
        listaCursos = new ListaCurso();
        listaDocentes = new ListaDocente();
        listaSecciones = new ListaSeccion();
        listaPeriodos = new ListaPeriodo();
    }

    public static BaseDeDatos getInstancia() {
        if (instancia == null) {
            instancia = new BaseDeDatos();
        }
        return instancia;
    }

    // Métodos de Búsqueda
    public NodoEstudiante buscarEstudiantePorCodigo(String codigo) {
        return listaEstudiantes.buscarPorCodigo(codigo);
    }
    
    public NodoEstudiante buscarEstudiantePorNombre(String nombre) {
        return listaEstudiantes.buscarPorNombre(nombre);
    }
    
    public NodoCurso buscarCursoPorCodigo(String codigo) {
        return listaCursos.buscarPorCodigo(codigo);
    }
    
    public NodoDocente buscarDocentePorId(String id) {
        return listaDocentes.buscarPorId(id);
    }

    public NodoSeccion buscarSeccionPorId(String id) {
        return listaSecciones.buscarPorId(id);
    }
    
    public NodoSeccion buscarSeccionPorDatos(String codigoCurso, String idDocente, String periodo) {
        return listaSecciones.buscarPorDatos(codigoCurso, idDocente, periodo);
    }

    // --- Búsqueda de Periodos ---
    public NodoPeriodo buscarPeriodoPorId(String id) {
        return listaPeriodos.buscarPorId(id);
    }
}