package HuellaEstudiantil.main;

import HuellaEstudiantil.datos.BaseDeDatos;
import HuellaEstudiantil.vista.Vista;

public class Principal {

    public static void main(String[] args) {

        // La llamada a inicializarDatos() se elimina porque el método ya no carga
        // datos de prueba. La simple llamada a getInstancia() es suficiente
        // para asegurar que la base de datos se cree al iniciar la aplicación.
        BaseDeDatos.getInstancia();
        Vista vista = new Vista();
        vista.mostrarMenu();
    }
}
