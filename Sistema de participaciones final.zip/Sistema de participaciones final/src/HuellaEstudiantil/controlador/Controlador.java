package HuellaEstudiantil.controlador;

import HuellaEstudiantil.datos.BaseDeDatos;
import HuellaEstudiantil.modelo.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

public class Controlador {

    private BaseDeDatos db;

    public Controlador() {
        this.db = BaseDeDatos.getInstancia();
    }
    
    // --- MÉTODOS AUXILIARES PARA VALIDACIÓN EN VISTA (UX) ---
    public boolean existeCurso(String codigo) {
        return db.buscarCursoPorCodigo(codigo) != null;
    }

    public boolean existeDocente(String id) {
        return db.buscarDocentePorId(id) != null;
    }

    // --- ALGORITMO DE ORDENAMIENTO  ---
    private void ordenamientoBurbuja(ArrayList<NodoEstudiante> lista) {
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (lista.get(j).getParticipaciones() < lista.get(j + 1).getParticipaciones()) {
                    NodoEstudiante aux = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, aux);
                }
            }
        }
    }

    // Lista fija de feriados
    private HashSet<LocalDate> obtenerFeriados() {
        HashSet<LocalDate> feriados = new HashSet<>();
        feriados.add(LocalDate.of(2025, 3, 25));   
        feriados.add(LocalDate.of(2025, 5, 1));   
        feriados.add(LocalDate.of(2025, 7, 28));  
        feriados.add(LocalDate.of(2025, 7, 29));  
        feriados.add(LocalDate.of(2025, 8, 30));  
        feriados.add(LocalDate.of(2025, 10, 8));  
        feriados.add(LocalDate.of(2025, 11, 1));  
        feriados.add(LocalDate.of(2025, 12, 8));  
        feriados.add(LocalDate.of(2025, 12, 25)); 
        return feriados;
    }
    
    private boolean esFeriado(LocalDate fecha, HashSet<LocalDate> feriados) {
        return feriados.contains(fecha);
    }
    
    // 2. GENERAR SESIONES DE CLASE
    public String generarSesiones(String idSeccion, LocalDate fechaInicio, DayOfWeek... dias) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return "Error: El ID de sección no se encuentra.";
        }
        
        if (fechaInicio == null) return "Error: No se ingresó la fecha de inicio.";
        if (dias == null || dias.length == 0) return "Error: No se ingresaron los días de la semana.";
        
        seccion.getSesionesDeClase().clear();
        
        String periodo = seccion.getPeriodo().toLowerCase();
        int totalSesiones;
        if (periodo.contains("verano")) {
            totalSesiones = 9;
        } else {
            totalSesiones = 18; 
        }
        
        HashSet<LocalDate> feriados = obtenerFeriados();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        StringBuilder resultado = new StringBuilder();
        resultado.append("SESIONES DE CLASE GENERADAS\n");
        resultado.append("============================\n");
        resultado.append("Sección: ").append(seccion.getId()).append("\n");
        resultado.append("Curso: ").append(seccion.getCurso().getNombre()).append("\n");
        resultado.append("Período: ").append(seccion.getPeriodo()).append("\n");
        resultado.append("Fecha de inicio: ").append(fechaInicio.format(formatoFecha)).append("\n");
        
        int numeroSesion = 1;
        LocalDate fechaActual = fechaInicio;
        int semanas = 0;
        
        while (numeroSesion <= totalSesiones) {
            for (DayOfWeek dia : dias) {
                if (numeroSesion > totalSesiones) break;
                
                int diasHastaDia = dia.getValue() - fechaActual.getDayOfWeek().getValue();
                if (diasHastaDia < 0) diasHastaDia += 7;
                LocalDate fechaSesion = fechaActual.plusDays(diasHastaDia);
                
                seccion.getSesionesDeClase().add(fechaSesion);
                
                if (esFeriado(fechaSesion, feriados)) {
                    resultado.append(String.format("Sesión %02d: A reprogramar %s\n", numeroSesion++, fechaSesion.format(formatoFecha)));
                } else {
                    String diaNombre = fechaSesion.getDayOfWeek().getDisplayName(TextStyle.FULL, new Locale("es", "ES"));
                    resultado.append(String.format("Sesión %02d: %s %s\n", numeroSesion++, diaNombre, fechaSesion.format(formatoFecha)));
                }
            }
            semanas++;
            fechaActual = fechaInicio.plusWeeks(semanas);
        }
        
        return resultado.toString();
    }

    // 1. MATRICULAR ESTUDIANTE EN SECCIÓN
    public String matricularEstudiante(String codigoEstudiante, String idSeccion) {
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El código de estudiante no se encuentra.";
        
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                return "Error: El estudiante ya se encuentra matriculado en esta sección.";
            }
        }
        
        int capacidadMaxima = seccion.getCurso().getCapacidadMaxima();
        if (seccion.getEstudiantesMatriculados().size() >= capacidadMaxima) {
            return "Error: La sección ha alcanzado su capacidad máxima.";
        }
        
        seccion.matricularEstudiante(estudiante);
        return "Estudiante " + estudiante.getNombre() + " (" + codigoEstudiante + ") matriculado exitosamente.";
    }
    
    // 3. REGISTRAR PARTICIPACIÓN
    public String registrarParticipacion(String idSeccion, String idEvaluacion, String semana, String sesion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El código de estudiante no se encuentra.";
        
        boolean estaMatriculado = false;
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                estaMatriculado = true;
                break;
            }
        }
        if (!estaMatriculado) return "Error: El estudiante no está matriculado en esta sección.";
        
        int participacionesActuales = seccion.obtenerParticipacionesPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        if (participacionesActuales >= 4) {
            return "Error: El estudiante ya ha alcanzado el límite de 4 participaciones para esta sesión/evaluación.";
        }
        
        seccion.incrementarParticipacionPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        estudiante.incrementarParticipacion();
        
        return "Participación registrada exitosamente. Total actual: " + (participacionesActuales + 1);
    }
    
    // 4. PROCESAR PARTICIPACIONES
    public String procesarParticipaciones(String idSeccion, String idEvaluacion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";
        
        if (seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return "Error: La evaluación ya ha sido procesada.";
        }

        ArrayList<NodoEstudiante> participantes = new ArrayList<>();
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getParticipaciones() > 0) participantes.add(e);
        }

        if (participantes.isEmpty()) {
            return "No hay estudiantes con participaciones registradas para procesar.";
        }
        
        ordenamientoBurbuja(participantes);
        
        StringBuilder resultado = new StringBuilder();
        resultado.append("PROCESAMIENTO DE PARTICIPACIONES\n");
        resultado.append("===============================\n");
        resultado.append("Sección: ").append(seccion.getId()).append("\n");
        resultado.append("Evaluación: ").append(idEvaluacion.toUpperCase()).append("\n\n");
        resultado.append("RANKING DE ESTUDIANTES:\n");
        
        int puntosDisponibles = 3;
        int posicion = 1;
        int participacionesAnteriores = -1;
        
        for (int i = 0; i < participantes.size(); i++) {
            NodoEstudiante estudiante = participantes.get(i);
            int participacionesActuales = estudiante.getParticipaciones();
            
            if (participacionesActuales != participacionesAnteriores) {
                if (i == 0) puntosDisponibles = 3;
                else if (i == 1) puntosDisponibles = 2;
                else puntosDisponibles = 1;
            }
            
            seccion.asignarPuntos(estudiante.getCodigo(), idEvaluacion, puntosDisponibles);
            resultado.append(String.format("%d. %s (%s) - %d participación(es) → %d puntos\n",
                posicion++, estudiante.getNombre(), estudiante.getCodigo(), participacionesActuales, puntosDisponibles));
            
            participacionesAnteriores = participacionesActuales;
            estudiante.setParticipaciones(0);
        }
        
        seccion.getEvaluacionesProcesadas().add(idEvaluacion.toUpperCase());
        return resultado.toString();
    }

    // 5. REGISTRAR ESTUDIANTE (MODIFICADO: Genera código y crea nuevo)
    public String registrarEstudiante(String nombre, String carrera, int ciclo) {
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        if (carrera == null || carrera.trim().isEmpty()) return "Error: El campo Carrera está vacío.";
        if (ciclo < 1 || ciclo > 12) return "Error: El Ciclo debe ser un número válido entre 1 y 12.";
        
        // Generación de código automático (Simulación para MVP)
        int cantidad = db.listaEstudiantes.getTodosComoArrayList().size();
        String nuevoCodigo = "U2025" + String.format("%03d", cantidad + 1);
        
        // Crear nuevo y agregar directamente (sin validar existente, creación pura)
        NodoEstudiante nuevoEst = new NodoEstudiante(nuevoCodigo, nombre, carrera, ciclo);
        db.listaEstudiantes.agregarAlFinal(nuevoEst);
        
        return "Estudiante registrado exitosamente.\n" +
               "Código: " + nuevoCodigo + "\n" +
               "Nombre: " + nombre + "\n" +
               "Carrera: " + carrera + "\n" +
               "Ciclo: " + ciclo;
    }

    // 6. REGISTRAR DOCENTE (MODIFICADO: Crea nuevo siempre)
    public String registrarDocente(String id, String nombre) {
        if (id == null || id.trim().isEmpty()) return "Error: El campo ID está vacío.";
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        
        // Validación de duplicados (Para que no cree dos iguales)
        if (db.buscarDocentePorId(id) != null) {
            return "Error: El ID del docente ya existe.";
        }
        
        // Creación pura
        NodoDocente nuevo = new NodoDocente(id, nombre);
        db.listaDocentes.agregarAlFinal(nuevo);
        
        return "Docente registrado exitosamente.\n" +
               "ID: " + id + "\n" +
               "Nombre: " + nombre;
    }

    // 7. REGISTRAR CURSO (MODIFICADO: Crea nuevo siempre)
    public String registrarCurso(String codigo, String nombre, String tipo, int capacidad) {
        if (codigo == null || codigo.trim().isEmpty()) return "Error: El campo Código está vacío.";
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        if (capacidad <= 0) return "Error: La Capacidad debe ser positiva.";
        
        // Validación de duplicados
        if (db.buscarCursoPorCodigo(codigo) != null) {
            return "Error: El código del curso ya existe.";
        }
        
        // Creación pura
        NodoCurso nuevo = new NodoCurso(codigo, nombre, tipo, capacidad);
        db.listaCursos.agregarAlFinal(nuevo);
        
        return "Curso registrado exitosamente.\n" +
               "Código: " + codigo + "\n" +
               "Nombre: " + nombre + "\n" +
               "Tipo: " + tipo + "\n" +
               "Capacidad Máxima: " + capacidad;
    }

    // 8. REGISTRAR SECCIÓN (MODIFICADO: Genera ID y crea nuevo)
    public String registrarSeccion(String codigoCurso, String idDocente, String periodo) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return "Error: Código vacío.";
        if (idDocente == null || idDocente.trim().isEmpty()) return "Error: ID Docente vacío.";
        
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: El código de curso no existe.";
        
        NodoDocente docente = db.buscarDocentePorId(idDocente);
        if (docente == null) return "Error: El ID de docente no existe.";
        
        // MEJORA: Validar si ya existe una sección con los mismos datos (Fail-Fast)
        if (db.buscarSeccionPorDatos(codigoCurso, idDocente, periodo) != null) {
            return "Error: Ya existe una sección con el mismo curso, docente y periodo.";
        }
        
        // Generar ID único para la sección
        String idSeccion = curso.getCodigo() + "-SEC" + (int)(Math.random() * 1000);
        
        NodoSeccion nueva = new NodoSeccion(idSeccion, curso, docente, periodo);
        db.listaSecciones.agregarAlFinal(nueva);
        
        return "Sección registrada exitosamente.\n" +
               "ID: " + idSeccion + "\n" +
               "Curso: " + curso.getNombre() + " (" + codigoCurso + ")\n" +
               "Docente: " + docente.getNombre() + " (" + idDocente + ")\n" +
               "Periodo: " + periodo;
    }

    // 9. DEFINIR ESTRUCTURA DE EVALUACIONES POR CURSO
    public String definirEvaluacion(String codigoCurso, String nombreEvaluacion) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return "Error: Código vacío.";
        if (nombreEvaluacion == null || nombreEvaluacion.trim().isEmpty()) return "Error: Nombre Eval vacío.";
        
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: El código de curso no existe.";
        
        for (String eval : curso.getEstructuraEvaluaciones()) {
            if (eval.equalsIgnoreCase(nombreEvaluacion.trim())) {
                return "Error: La evaluación '" + nombreEvaluacion + "' ya existe.";
            }
        }
        
        curso.agregarEvaluacion(nombreEvaluacion.trim());
        
        return "Evaluación agregada exitosamente.\n" +
               "Curso: " + curso.getNombre() + "\n" +
               "Evaluación: " + nombreEvaluacion;
    }

    // 10. AJUSTAR MANUALMENTE EL CONTEO DE PARTICIPACIONES
    public String ajustarParticipaciones(String idSeccion, String idEvaluacion, String codigoEstudiante, int nuevoPuntaje) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";
        
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El estudiante no existe.";
        
        if (!seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return "Error: La evaluación '" + idEvaluacion + "' no ha sido procesada aún.";
        }
        
        if (nuevoPuntaje < 0) return "Error: El nuevo puntaje debe ser válido.";
        
        Integer puntajeAnterior = seccion.obtenerPuntos(codigoEstudiante, idEvaluacion);
        if (puntajeAnterior == null) puntajeAnterior = 0;
        
        seccion.asignarPuntos(codigoEstudiante, idEvaluacion, nuevoPuntaje);
        
        return "Ajuste manual registrado exitosamente.\n" +
               "Estudiante: " + estudiante.getNombre() + "\n" +
               "Puntaje anterior: " + puntajeAnterior + "\n" +
               "Nuevo puntaje: " + nuevoPuntaje;
    }
}