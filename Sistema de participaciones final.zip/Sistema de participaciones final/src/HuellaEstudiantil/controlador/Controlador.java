package HuellaEstudiantil.controlador;

import HuellaEstudiantil.datos.BaseDeDatos;
import HuellaEstudiantil.modelo.*;
import java.time.DayOfWeek;
import java.time.temporal.ChronoUnit;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Collections;
import java.util.Locale;

public class Controlador {

    private BaseDeDatos db;

    public Controlador() {
        this.db = BaseDeDatos.getInstancia();
    }
    
    // --- MÉTODOS AUXILIARES PARA VALIDACIÓN EN VISTA (UX) ---
    public boolean existeCurso(String codigo) {
        return db.buscarCursoPorCodigo(codigo) != null;
    }

    public boolean existeDocente(String id) {
        return db.buscarDocentePorId(id) != null;
    }

    public boolean existeSeccion(String id) {
        return db.buscarSeccionPorId(id) != null;
    }

    public boolean existeEstudiante(String nombre, String carrera) {
        ArrayList<NodoEstudiante> todosLosEstudiantes = db.listaEstudiantes.getTodosComoArrayList();
        for (NodoEstudiante estudiante : todosLosEstudiantes) {
            if (estudiante.getNombre().equalsIgnoreCase(nombre.trim()) && 
                estudiante.getCarrera().equalsIgnoreCase(carrera.trim())) {
                return true;
            }
        }
        return false;
    }

    public boolean existeEstudiantePorCodigo(String codigo) {
        return db.buscarEstudiantePorCodigo(codigo) != null;
    }

    public boolean estaMatriculado(String idSeccion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return false;
        }
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                return true;
            }
        }
        return false;
    }

    public boolean existeEvaluacionEnCurso(String idSeccion, String nombreEvaluacion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return false;

        NodoCurso curso = seccion.getCurso();
        if (curso == null) return false;

        for (String eval : curso.getEstructuraEvaluaciones()) {
            if (eval.equalsIgnoreCase(nombreEvaluacion.trim())) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<String> obtenerEvaluacionesDeCurso(String idSeccion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion != null) {
            NodoCurso curso = seccion.getCurso();
            if (curso != null) {
                return curso.getEstructuraEvaluaciones(); // Devuelve la lista directamente
            }
        }
        // Si la sección o el curso no existen, devuelve una lista vacía.
        return new ArrayList<>();
    }

    public ArrayList<String> obtenerSesionesDisponibles(String idSeccion) {
        ArrayList<String> sesionesFormateadas = new ArrayList<>();
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            for (LocalDate sesion : seccion.getSesionesDeClase()) {
                sesionesFormateadas.add(sesion.format(formatter));
            }
        }
        return sesionesFormateadas;
    }

    public ArrayList<String> obtenerSesionesPorSemana(String idSeccion, int numeroSemana) {
        ArrayList<String> sesionesFiltradas = new ArrayList<>();
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null || seccion.getSesionesDeClase().isEmpty()) {
            return sesionesFiltradas; // Retorna lista vacía
        }

        ArrayList<LocalDate> todasLasSesiones = seccion.getSesionesDeClase();
        LocalDate fechaBase = todasLasSesiones.get(0); // Primera sesión como referencia
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        for (LocalDate fechaActual : todasLasSesiones) {
            long diasDeDiferencia = ChronoUnit.DAYS.between(fechaBase, fechaActual);
            int semanaActual = (int) (diasDeDiferencia / 7) + 1;

            if (semanaActual == numeroSemana) {
                sesionesFiltradas.add(fechaActual.format(formatter));
            }
        }

        return sesionesFiltradas;
    }

    public boolean esFechaValidaParaSeccion(String idSeccion, LocalDate nuevaFecha) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return false;
        }
        NodoPeriodo periodo = db.buscarPeriodoPorId(seccion.getPeriodo());
        if (periodo == null) {
            return false;
        }

        // Retorna true si la nuevaFecha está dentro del rango del periodo (inclusive)
        return !nuevaFecha.isBefore(periodo.getFechaInicio()) && !nuevaFecha.isAfter(periodo.getFechaFin());
    }


    public boolean fechaEstaOcupada(LocalDate fecha) {
        ArrayList<NodoPeriodo> periodos = db.listaPeriodos.getTodosComoArrayList();
        for (NodoPeriodo p : periodos) {
            // Verifica si la fecha está dentro del rango de un periodo existente (inclusivo)
            if ((fecha.isEqual(p.getFechaInicio()) || fecha.isAfter(p.getFechaInicio())) &&
                (fecha.isEqual(p.getFechaFin()) || fecha.isBefore(p.getFechaFin()))) {
                return true; // La fecha está ocupada
            }
        }
        return false; // La fecha está libre
    }

    private boolean existeTraslape(int anio, LocalDate nuevoInicio, LocalDate nuevoFin) {
        ArrayList<NodoPeriodo> periodos = db.listaPeriodos.getTodosComoArrayList();
        for (NodoPeriodo p : periodos) {
            // Solo comparar con periodos del mismo año
            if (p.getAnio() == anio) {
                // Lógica de traslape: (Inicio1 <= Fin2) y (Fin1 >= Inicio2)
                if (!nuevoInicio.isAfter(p.getFechaFin()) && !nuevoFin.isBefore(p.getFechaInicio())) {
                    return true; // Se encontró un traslape
                }
            }
        }
        return false; // No hay traslapes
    }

    public ArrayList<String> obtenerEstudiantesDeSeccion(String idSeccion) {
        ArrayList<String> estudiantesFormateados = new ArrayList<>();
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion != null) {
            // Asumiendo que seccion.getEstudiantesMatriculados() devuelve una lista de NodoEstudiante
            for (NodoEstudiante estudiante : seccion.getEstudiantesMatriculados()) {
                if (estudiante.isActivo()) { // <-- REQUERIMIENTO: Solo mostrar estudiantes activos
                    estudiantesFormateados.add(estudiante.getCodigo() + " - " + estudiante.getNombre());
                }
            }
        }
        return estudiantesFormateados;
    }

    /**
     * Calcula dinámicamente el número de semanas calendario para una sección dada,
     * basándose en las fechas de inicio y fin de su periodo académico.
     * @param idSeccion El ID de la sección.
     * @return El número total de semanas calendario que abarca el periodo.
     */
    public int obtenerSemanasDeSeccion(String idSeccion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion != null) {
            NodoPeriodo periodo = db.buscarPeriodoPorId(seccion.getPeriodo());
            if (periodo != null) {
                long diasTotales = ChronoUnit.DAYS.between(periodo.getFechaInicio(), periodo.getFechaFin()) + 1;
                // Redondea hacia arriba para contar cualquier semana parcialmente utilizada.
                return (int) Math.ceil(diasTotales / 7.0);
            }
        }
        return 0; // Retorna 0 si la sección o el periodo no se encuentran.
    }

    // --- LÓGICA PARA GESTIÓN DE PERIODOS ACADÉMICOS ---

    /**
     * Método auxiliar para verificar si un periodo ya existe por su ID.
     *
     * @param id El ID del periodo a verificar (ej. "2025-Marzo").
     * @return true si el periodo ya existe, false en caso contrario.
     */
    public boolean existePeriodo(String id) {
        return db.buscarPeriodoPorId(id) != null;
    }

    /**
     * Registra un nuevo periodo académico tras validar los datos.
     *
     * @param anio    Año del periodo.
     * @param periodo Nombre del periodo ("Verano", "Marzo", "Agosto").
     * @param inicio  Fecha de inicio del periodo.
     * @param fin     Fecha de fin del periodo.
     * @return Un mensaje de String indicando el resultado de la operación.
     */
    public String registrarPeriodo(int anio, String periodo, LocalDate inicio, LocalDate fin) {
        // Generación automática del ID
        String id = anio + "-" + periodo;

        // VALIDACIÓN 1 (Fail-Fast): Verificar si el periodo ya existe.
        if (existePeriodo(id)) {
            return "Error: El periodo '" + id + "' ya existe.";
        }

        // VALIDACIÓN 2 (Fechas): La fecha de fin no puede ser anterior a la de inicio.
        if (fin.isBefore(inicio)) {
            return "Error: La fecha de fin no puede ser anterior a la fecha de inicio.";
        }

        // VALIDACIÓN 3 (Coherencia): El año de la fecha de inicio debe coincidir con el año proporcionado.
        if (inicio.getYear() != anio) {
            return "Error: El año de la fecha de inicio (" + inicio.getYear() + ") no coincide con el año del periodo (" + anio + ").";
        }

        // VALIDACIÓN 4 (Traslape): Las fechas no deben cruzarse con otros periodos del mismo año.
        if (existeTraslape(anio, inicio, fin)) {
            return "Error: Las fechas indicadas se cruzan con otro periodo existente en el año " + anio + ".";
        }

        // Si todas las validaciones pasan, se crea y agrega el nodo.
        NodoPeriodo nuevoPeriodo = new NodoPeriodo(id, anio, periodo, inicio, fin);
        db.listaPeriodos.agregarAlFinal(nuevoPeriodo);

        return "Periodo '" + id + "' registrado exitosamente.";
    }

    public ArrayList<String> obtenerIDsPeriodos() {
        ArrayList<String> idsPeriodos = new ArrayList<>();
        ArrayList<NodoPeriodo> todosLosPeriodos = db.listaPeriodos.getTodosComoArrayList();
        for (NodoPeriodo periodo : todosLosPeriodos) {
            idsPeriodos.add(periodo.getId());
        }
        return idsPeriodos;
    }

    public ArrayList<String> obtenerIDsTodasLasSecciones() {
        ArrayList<String> idsSecciones = new ArrayList<>();
        ArrayList<NodoSeccion> todasLasSecciones = db.listaSecciones.getTodosComoArrayList();
        for (NodoSeccion seccion : todasLasSecciones) {
            idsSecciones.add(seccion.getId());
        }
        return idsSecciones;
    }

    public ArrayList<String> obtenerEstudiantesParaMatricula(String idSeccion) {
        ArrayList<String> estudiantesFormateados = new ArrayList<>();
        
        // Obtener la sección para saber quiénes ya están matriculados
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return estudiantesFormateados; // Retorna lista vacía si la sección no existe
        }
        
        // Crear un conjunto de códigos de estudiantes ya matriculados para una búsqueda eficiente
        HashSet<String> codigosMatriculados = new HashSet<>();
        for (NodoEstudiante matriculado : seccion.getEstudiantesMatriculados()) {
            codigosMatriculados.add(matriculado.getCodigo());
        }

        ArrayList<NodoEstudiante> todosLosEstudiantes = db.listaEstudiantes.getTodosComoArrayList();
        for (NodoEstudiante estudiante : todosLosEstudiantes) {
            // REQUERIMIENTO: Mostrar solo estudiantes activos Y que NO estén ya matriculados en esta sección.
            if (estudiante.isActivo() && !codigosMatriculados.contains(estudiante.getCodigo())) {
                estudiantesFormateados.add(estudiante.getCodigo() + " - " + estudiante.getNombre());
            }
        }
        return estudiantesFormateados;
    }

    public ArrayList<String> obtenerCursosFormateados() {
        ArrayList<String> cursosFormateados = new ArrayList<>();
        ArrayList<NodoCurso> todosLosCursos = db.listaCursos.getTodosComoArrayList();
        for (NodoCurso curso : todosLosCursos) {
            cursosFormateados.add(curso.getCodigo() + " - " + curso.getNombre());
        }
        return cursosFormateados;
    }

    public ArrayList<String> obtenerDocentesFormateados() {
        ArrayList<String> docentesFormateados = new ArrayList<>();
        ArrayList<NodoDocente> todosLosDocentes = db.listaDocentes.getTodosComoArrayList();
        for (NodoDocente docente : todosLosDocentes) {
            docentesFormateados.add(docente.getId() + " - " + docente.getNombre());
        }
        return docentesFormateados;
    }

    public ArrayList<String> obtenerEstudiantesConEstado() {
        ArrayList<String> estudiantesFormateados = new ArrayList<>();
        ArrayList<NodoEstudiante> todosLosEstudiantes = db.listaEstudiantes.getTodosComoArrayList();
        for (NodoEstudiante estudiante : todosLosEstudiantes) {
            String estado = estudiante.isActivo() ? "[ACTIVO]" : "[INACTIVO]";
            estudiantesFormateados.add(estudiante.getCodigo() + " - " + estudiante.getNombre() + " " + estado);
        }
        return estudiantesFormateados;
    }


    // --- ALGORITMO DE ORDENAMIENTO  ---
    private void ordenamientoBurbuja(ArrayList<NodoEstudiante> lista) {
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            // Este método ahora es específico para una evaluación, por lo que no puede ser genérico.
            // La lógica de ordenamiento se moverá directamente a `procesarParticipaciones`.
            // Se deja vacío para evitar su uso incorrecto.
        }
    }

    // Lista fija de feriados
    private HashSet<LocalDate> obtenerFeriados() {
        HashSet<LocalDate> feriados = new HashSet<>();
        feriados.add(LocalDate.of(2025, 3, 25));   
        feriados.add(LocalDate.of(2025, 5, 1));   
        feriados.add(LocalDate.of(2025, 7, 28));  
        feriados.add(LocalDate.of(2025, 7, 29));  
        feriados.add(LocalDate.of(2025, 8, 30));  
        feriados.add(LocalDate.of(2025, 10, 8));  
        feriados.add(LocalDate.of(2025, 11, 1));  
        feriados.add(LocalDate.of(2025, 12, 8));  
        feriados.add(LocalDate.of(2025, 12, 25)); 
        return feriados;
    }
    
    /**
     * Verifica si una fecha específica es un feriado definido en el sistema.
     * @param fecha La fecha a verificar.
     * @return true si es feriado, false en caso contrario.
     */
    public boolean esFeriado(LocalDate fecha) {
        return obtenerFeriados().contains(fecha);
    }
    
    // 2. GENERAR SESIONES DE CLASE
    public String generarSesiones(String idSeccion, DayOfWeek... dias) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return "Error: El ID de sección no se encuentra.";
        }
        
        // Lógica para obtener la fecha de inicio automáticamente del periodo
        String idPeriodo = seccion.getPeriodo();
        NodoPeriodo periodoObj = db.buscarPeriodoPorId(idPeriodo);
        if (periodoObj == null) {
            return "Error: El periodo académico '" + idPeriodo + "' asociado a la sección no fue encontrado.";
        }
        // 1. Obtener fechas oficiales del periodo
        LocalDate inicioPeriodo = periodoObj.getFechaInicio();
        LocalDate finPeriodo = periodoObj.getFechaFin();
        
        if (dias == null || dias.length == 0) return "Error: No se ingresaron los días de la semana.";
        
        seccion.getSesionesDeClase().clear(); // Limpiamos sesiones anteriores antes de generar nuevas
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        StringBuilder resultado = new StringBuilder();
        resultado.append("SESIONES DE CLASE GENERADAS\n");
        resultado.append("============================\n");
        resultado.append("Sección: ").append(seccion.getId()).append(" | Curso: ").append(seccion.getCurso().getNombre()).append("\n");
        resultado.append("Período: ").append(idPeriodo).append(" (").append(inicioPeriodo.format(formatoFecha)).append(" a ").append(finPeriodo.format(formatoFecha)).append(")\n");
        
        int numeroSesion = 1;
        
        // 2. Nuevo Algoritmo de Generación (Bucle Controlado por Fechas)
        LocalDate inicioSemana = inicioPeriodo;
        int numeroSemana = 1;

        while (!inicioSemana.isAfter(finPeriodo)) {
            boolean semanaTieneSesiones = false;
            StringBuilder sesionesDeLaSemana = new StringBuilder();

            for (DayOfWeek dia : dias) {
                int diasHastaDia = dia.getValue() - inicioSemana.getDayOfWeek().getValue();
                if (diasHastaDia < 0) diasHastaDia += 7;
                LocalDate fechaSesion = inicioSemana.plusDays(diasHastaDia);

                // VALIDACIÓN CRÍTICA: No generar sesiones fuera del rango del periodo
                if (fechaSesion.isAfter(finPeriodo)) {
                    continue; // Salta esta iteración, la fecha está fuera de los límites.
                }
                
                semanaTieneSesiones = true; // Marcamos que esta semana sí tiene al menos una sesión
                seccion.getSesionesDeClase().add(fechaSesion);
                
                if (esFeriado(fechaSesion)) {
                    sesionesDeLaSemana.append(String.format("Sesión %02d: [FERIADO] %s (%s)\n", numeroSesion++, fechaSesion.format(formatoFecha), dia.getDisplayName(TextStyle.FULL, new Locale("es", "ES"))));
                } else {
                    sesionesDeLaSemana.append(String.format("Sesión %02d: %s (%s)\n", numeroSesion++, fechaSesion.format(formatoFecha), dia.getDisplayName(TextStyle.FULL, new Locale("es", "ES"))));
                }
            }
            
            // Solo agregar el bloque de la semana al resultado si tuvo sesiones válidas
            if (semanaTieneSesiones) {
                resultado.append("\n--- SEMANA ").append(numeroSemana).append(" ---\n");
                resultado.append(sesionesDeLaSemana);
            }
            
            inicioSemana = inicioSemana.plusWeeks(1);
            numeroSemana++;
        }
        
        return resultado.toString();
    }

    // 1. MATRICULAR ESTUDIANTE EN SECCIÓN
    public String matricularEstudiante(String codigoEstudiante, String idSeccion) {
        // Este método ahora es un envoltorio para la matriculación múltiple
        ArrayList<String> codigos = new ArrayList<>();
        codigos.add(codigoEstudiante);
        return matricularMultiplesEstudiantes(codigos, idSeccion);
    }

    public String matricularMultiplesEstudiantes(ArrayList<String> codigosEstudiantes, String idSeccion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return "Error: El ID de sección no se encuentra.";
        }

        int exitosos = 0;
        int fallidos = 0;
        StringBuilder detallesFallidos = new StringBuilder();

        for (String codigoEstudiante : codigosEstudiantes) {
            NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
            if (estudiante == null) {
                fallidos++;
                detallesFallidos.append("- Código '").append(codigoEstudiante).append("' no encontrado.\n");
                continue;
            }

            // REQUERIMIENTO: No matricular estudiantes inactivos
            if (!estudiante.isActivo()) {
                fallidos++;
                detallesFallidos.append("- ").append(estudiante.getNombre()).append(" está inactivo y no puede ser matriculado.\n");
                continue;
            }
            boolean yaMatriculado = false;
            for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
                if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                    yaMatriculado = true;
                    break;
                }
            }

            if (yaMatriculado) {
                fallidos++;
                detallesFallidos.append("- ").append(estudiante.getNombre()).append(" ya estaba matriculado.\n");
            } else if (seccion.getEstudiantesMatriculados().size() >= seccion.getCurso().getCapacidadMaxima()) {
                fallidos++;
                detallesFallidos.append("- No se pudo matricular a ").append(estudiante.getNombre()).append(" (sección llena).\n");
            } else {
                seccion.matricularEstudiante(estudiante);
                exitosos++;
            }
        }

        String resumen = "Matrícula completada.\n\n" +
                         "Estudiantes matriculados exitosamente: " + exitosos + "\n" +
                         "Matrículas fallidas: " + fallidos;

        if (fallidos > 0) {
            resumen += "\n\nDetalles de fallos:\n" + detallesFallidos.toString();
        }

        return resumen;
    }
    
    // 3. REGISTRAR PARTICIPACIÓN
    public String registrarParticipacion(String idSeccion, String idEvaluacion, String semana, String sesion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El código de estudiante no se encuentra.";
        
        // REQUERIMIENTO: Validar que el estudiante esté activo
        if (!estudiante.isActivo()) {
            return "Error: El estudiante " + estudiante.getNombre() + " se encuentra inactivo.";
        }

        boolean estaMatriculado = false;
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                estaMatriculado = true;
                break;
            }
        }
        if (!estaMatriculado) return "Error: El estudiante no está matriculado en esta sección.";
        
        int participacionesActuales = seccion.obtenerParticipacionesPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        if (participacionesActuales >= 4) {
            return "Error: El estudiante ya ha alcanzado el límite de 4 participaciones para esta sesión/evaluación.";
        }
        
        seccion.incrementarParticipacionPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        estudiante.incrementarParticipacion(idEvaluacion);
        
        return "Participación registrada exitosamente. Total actual: " + (participacionesActuales + 1);
    }
    
    // 4. PROCESAR PARTICIPACIONES
    public String procesarParticipaciones(String idSeccion, String idEvaluacion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";
        
        if (seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return "Error: La evaluación ya ha sido procesada.";
        }

        // 1. Obtener TODOS los estudiantes matriculados, no solo los que participaron.
        ArrayList<NodoEstudiante> matriculadosActivos = new ArrayList<>();
        for (NodoEstudiante est : seccion.getEstudiantesMatriculados()) {
            if (est.isActivo()) { // <-- REQUERIMIENTO: Filtrar solo los activos
                matriculadosActivos.add(est);
            }
        }

        if (matriculadosActivos.isEmpty()) {
            return "No hay estudiantes matriculados en esta sección para procesar.";
        }
        
        // 2. Ordenar a los estudiantes activos por su número de participaciones para la evaluación específica.
        final String eval = idEvaluacion.toUpperCase();
        matriculadosActivos.sort((e1, e2) -> {
            int p1 = e1.getParticipaciones(eval);
            int p2 = e2.getParticipaciones(eval);
            // Orden descendente
            return Integer.compare(p2, p1);
        });
        // La lógica de ordenamiento burbuja se reemplaza por un método más moderno y claro,
        // y se mueve aquí para tener el contexto de la evaluación.
        // ordenamientoBurbuja(matriculadosActivos); // Ya no se usa el método genérico.
        
        StringBuilder resultado = new StringBuilder();
        resultado.append("PROCESAMIENTO DE PARTICIPACIONES\n");
        resultado.append("===============================\n");
        resultado.append("Sección: ").append(seccion.getId()).append("\n");
        resultado.append("Evaluación: ").append(idEvaluacion.toUpperCase()).append("\n\n");
        resultado.append("RESULTADOS DE LA CLASE:\n");
        
        int puntosDisponibles = 3;
        int posicion = 1;
        int participacionesAnteriores = -1;
        
        // 3. Iterar sobre TODOS los estudiantes matriculados.
        for (int i = 0; i < matriculadosActivos.size(); i++) {
            NodoEstudiante estudiante = matriculadosActivos.get(i);
            int participacionesActuales = estudiante.getParticipaciones(eval);
            int puntosAsignados = 0;

            // 4. Asignar puntos solo si el estudiante participó.
            // Lógica de Grupos de Mérito
            if (participacionesActuales > 0 && i < 5) { // Solo los 5 primeros con participaciones reciben puntos
                if (i == 0) {
                    puntosAsignados = 3; // 1er Puesto
                } else if (i >= 1 && i <= 2) {
                    puntosAsignados = 2; // 2do y 3er Puesto
                } else if (i >= 3 && i <= 4) {
                    puntosAsignados = 1; // 4to y 5to Puesto
                } else {
                    puntosAsignados = 0; // Del 6to en adelante
                }
            }
            
            seccion.asignarPuntos(estudiante.getCodigo(), eval, puntosAsignados);
            resultado.append(String.format("%d. %s (%s) - %d participación(es) → %d puntos\n",
                posicion++, estudiante.getNombre(), estudiante.getCodigo(), participacionesActuales, puntosAsignados));
            
            // 5. Resetear las participaciones del alumno SOLO para esta evaluación.
            estudiante.reiniciarParticipaciones(eval);
        }
        
        seccion.getEvaluacionesProcesadas().add(idEvaluacion.toUpperCase());
        return resultado.toString();
    }

    // 5. REGISTRAR ESTUDIANTE (MODIFICADO: Genera código y crea nuevo)
    public String registrarEstudiante(String nombre, String carrera, int ciclo) {
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        if (carrera == null || carrera.trim().isEmpty()) return "Error: El campo Carrera está vacío.";
        if (ciclo < 1 || ciclo > 12) return "Error: El Ciclo debe ser un número válido entre 1 y 12.";
        
        // Generación de código automático (Simulación para MVP)
        int cantidad = db.listaEstudiantes.getTodosComoArrayList().size();
        String nuevoCodigo = "U2025" + String.format("%03d", cantidad + 1);
        
        // Crear nuevo y agregar directamente (sin validar existente, creación pura)
        NodoEstudiante nuevoEst = new NodoEstudiante(nuevoCodigo, nombre, carrera, ciclo);
        db.listaEstudiantes.agregarAlFinal(nuevoEst);
        
        return "Estudiante registrado exitosamente.\n" +
               "Código: " + nuevoCodigo + "\n" +
               "Nombre: " + nombre + "\n" +
               "Carrera: " + carrera + "\n" +
               "Ciclo: " + ciclo;
    }

    // 6. REGISTRAR DOCENTE (MODIFICADO: Crea nuevo siempre)
    public String registrarDocente(String id, String nombre) {
        if (id == null || id.trim().isEmpty()) return "Error: El campo ID está vacío.";
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        
        // Validación de duplicados (Para que no cree dos iguales)
        if (db.buscarDocentePorId(id) != null) {
            return "Error: El ID del docente ya existe.";
        }
        
        // Creación pura
        NodoDocente nuevo = new NodoDocente(id, nombre);
        db.listaDocentes.agregarAlFinal(nuevo);
        
        return "Docente registrado exitosamente.\n" +
               "ID: " + id + "\n" +
               "Nombre: " + nombre;
    }

    // 7. REGISTRAR CURSO (MODIFICADO: Crea nuevo siempre)
    public String registrarCurso(String codigo, String nombre, String tipo, int capacidad) {
        if (codigo == null || codigo.trim().isEmpty()) return "Error: El campo Código está vacío.";
        if (nombre == null || nombre.trim().isEmpty()) return "Error: El campo Nombre está vacío.";
        if (capacidad <= 0) return "Error: La Capacidad debe ser positiva.";
        
        // Validación de duplicados
        if (db.buscarCursoPorCodigo(codigo) != null) {
            return "Error: El código del curso ya existe.";
        }
        
        // Creación pura
        NodoCurso nuevo = new NodoCurso(codigo, nombre, tipo, capacidad);
        db.listaCursos.agregarAlFinal(nuevo);
        
        return "Curso registrado exitosamente.\n" +
               "Código: " + codigo + "\n" +
               "Nombre: " + nombre + "\n" +
               "Tipo: " + tipo + "\n" +
               "Capacidad Máxima: " + capacidad;
    }

    // 8. REGISTRAR SECCIÓN (MODIFICADO: Genera ID y crea nuevo)
    public String registrarSeccion(String codigoCurso, String idDocente, String periodo) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return "Error: Código vacío.";
        if (idDocente == null || idDocente.trim().isEmpty()) return "Error: ID Docente vacío.";
        
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: El código de curso no existe.";
        
        NodoDocente docente = db.buscarDocentePorId(idDocente);
        if (docente == null) return "Error: El ID de docente no existe.";
        
        // MEJORA: Validar si ya existe una sección con los mismos datos (Fail-Fast)
        if (db.buscarSeccionPorDatos(codigoCurso, idDocente, periodo) != null) {
            return "Error: Ya existe una sección con el mismo curso, docente y periodo.";
        }
        
        // Generar ID único para la sección
        String idSeccion = curso.getCodigo() + "-SEC" + (int)(Math.random() * 1000);
        
        NodoSeccion nueva = new NodoSeccion(idSeccion, curso, docente, periodo);
        db.listaSecciones.agregarAlFinal(nueva);
        
        return "Sección registrada exitosamente.\n" +
               "ID: " + idSeccion + "\n" +
               "Curso: " + curso.getNombre() + " (" + codigoCurso + ")\n" +
               "Docente: " + docente.getNombre() + " (" + idDocente + ")\n" +
               "Periodo: " + periodo;
    }

    // 9. DEFINIR ESTRUCTURA DE EVALUACIONES POR CURSO
    public String definirEvaluacion(String codigoCurso, String nombreEvaluacion) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return "Error: Código vacío.";
        if (nombreEvaluacion == null || nombreEvaluacion.trim().isEmpty()) return "Error: Nombre Eval vacío.";
        
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: El código de curso no existe.";
        
        for (String eval : curso.getEstructuraEvaluaciones()) {
            if (eval.equalsIgnoreCase(nombreEvaluacion.trim())) {
                return "Error: La evaluación '" + nombreEvaluacion + "' ya existe.";
            }
        }
        
        curso.agregarEvaluacion(nombreEvaluacion.trim());
        
        return "Evaluación agregada exitosamente.\n" +
               "Curso: " + curso.getNombre() + "\n" +
               "Evaluación: " + nombreEvaluacion;
    }

    // 10. AJUSTAR MANUALMENTE EL CONTEO DE PARTICIPACIONES
    public String ajustarParticipaciones(String idSeccion, String idEvaluacion, String codigoEstudiante, int nuevoPuntaje) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";
        
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El estudiante no existe.";
        
        // REQUERIMIENTO: Validar que el estudiante esté activo
        if (!estudiante.isActivo()) {
            return "Error: El estudiante " + estudiante.getNombre() + " se encuentra inactivo.";
        }

        if (!seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return "Error: La evaluación '" + idEvaluacion + "' no ha sido procesada aún.";
        }
        
        if (nuevoPuntaje < 0) return "Error: El nuevo puntaje debe ser válido.";
        
        Integer puntajeAnterior = seccion.obtenerPuntos(codigoEstudiante, idEvaluacion);
        if (puntajeAnterior == null) puntajeAnterior = 0;
        
        seccion.asignarPuntos(codigoEstudiante, idEvaluacion, nuevoPuntaje);
        
        return "Ajuste manual registrado exitosamente.\n" +
               "Estudiante: " + estudiante.getNombre() + "\n" +
               "Puntaje anterior: " + puntajeAnterior + "\n" +
               "Nuevo puntaje: " + nuevoPuntaje;
    }

    /**
     * Consulta el puntaje actual de un estudiante para una evaluación ya procesada.
     * @param idSeccion El ID de la sección.
     * @param idEvaluacion El nombre de la evaluación.
     * @param codigoEstudiante El código del estudiante.
     * @return El puntaje como Integer, o null si no se encuentra o no ha sido procesado.
     */
    public Integer consultarPuntajeActual(String idSeccion, String idEvaluacion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null || !seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return null;
        }
        return seccion.obtenerPuntos(codigoEstudiante, idEvaluacion);
    }

    // 11. INHABILITAR/HABILITAR ESTUDIANTE
    public String cambiarEstadoEstudiante(String codigo) {
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigo);
        if (estudiante == null) {
            return "Error: Estudiante no encontrado.";
        }

        // Invertir el estado actual
        estudiante.setActivo(!estudiante.isActivo());

        String nuevoEstado = estudiante.isActivo() ? "Activo" : "Inactivo";

        return "El estado del estudiante " + estudiante.getNombre() + " (" + estudiante.getCodigo() + ") " +
               "ha sido cambiado a " + nuevoEstado + ".";
    }

    // 12. CONSULTAR HISTORIAL DE PUNTOS
    public String consultarHistorial(String idSeccion, String codigoEstudiante) {
        // a. Validar que la Sección exista
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return "Error: Sección no encontrada.";
        }

        // b. Validar que el Estudiante exista
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) {
            return "Error: Estudiante no encontrado.";
        }

        // REQUERIMIENTO: Validar que el estudiante esté activo
        if (!estudiante.isActivo()) {
            // Aunque la lista ya viene filtrada, esta es una validación de seguridad adicional.
            return "Error: El estudiante " + estudiante.getNombre() + " se encuentra inactivo.";
        }

        // c. Validar matrícula
        boolean estaMatriculado = false;
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                estaMatriculado = true;
                break;
            }
        }
        if (!estaMatriculado) {
            return "Error: El estudiante no pertenece a esta sección.";
        }

        // d. Generación del Reporte
        StringBuilder reporte = new StringBuilder();
        reporte.append("HISTORIAL DE PUNTOS\n");
        reporte.append("===================\n");
        reporte.append("Estudiante: ").append(estudiante.getNombre()).append(" (").append(estudiante.getCodigo()).append(")\n");
        reporte.append("Sección: ").append(idSeccion).append("\n\n");

        HashSet<String> evaluacionesProcesadas = seccion.getEvaluacionesProcesadas();
        if (evaluacionesProcesadas.isEmpty()) {
            return reporte.toString() + "Aún no se han procesado evaluaciones en esta sección.";
        }

        // REFACTOR: Obtener la estructura ordenada de evaluaciones del curso para mostrarlas en orden.
        ArrayList<String> estructuraOrdenada = seccion.getCurso().getEstructuraEvaluaciones();
        int totalPuntos = 0;
        boolean hayEvaluacionesParaMostrar = false;

        for (String evaluacion : estructuraOrdenada) {
            // Mostrar la evaluación solo si ha sido procesada
            if (evaluacionesProcesadas.contains(evaluacion.toUpperCase())) {
                hayEvaluacionesParaMostrar = true;
                Integer puntos = seccion.obtenerPuntos(codigoEstudiante, evaluacion);
                int puntosObtenidos = (puntos != null) ? puntos : 0;
                reporte.append("- ").append(evaluacion).append(": ").append(puntosObtenidos).append(" pts\n");
                totalPuntos += puntosObtenidos;
            }
        }

        if (!hayEvaluacionesParaMostrar) return reporte.toString() + "Aún no se han procesado evaluaciones en esta sección.";

        reporte.append("\n-------------------\n");
        reporte.append("TOTAL ACUMULADO: ").append(totalPuntos).append(" pts");

        return reporte.toString();
    }

    // 13. REGISTRAR NOTAS DE EVALUACIONES
    public String registrarNotaAcademica(String idSeccion, String idEvaluacion, String codigoEstudiante, int nota) {
        // a. Validar rango de nota
        if (nota < 0 || nota > 20) {
            return "Error: La nota debe estar entre 0 y 20.";
        }

        // b. Validar que la sección y el estudiante existan
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";

        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El estudiante no existe.";

        // c. Validar que el estudiante esté matriculado
        if (!estaMatriculado(idSeccion, codigoEstudiante)) {
            return "Error: El estudiante no está matriculado en esta sección.";
        }

        // d. Validar que la evaluación exista en la estructura del curso
        if (!existeEvaluacionEnCurso(idSeccion, idEvaluacion)) {
            return "Error: La evaluación '" + idEvaluacion + "' no corresponde a este curso.";
        }

        // Acción
        seccion.registrarNota(codigoEstudiante, idEvaluacion, nota);

        return "Nota registrada exitosamente para " + estudiante.getNombre() + " en " + idEvaluacion.toUpperCase() + ".";
    }

    public int consultarNotaActual(String idSeccion, String idEvaluacion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return 0; // O un valor que indique error, pero 0 es seguro para la vista
        }
        Integer nota = seccion.obtenerNota(codigoEstudiante, idEvaluacion);
        if (nota == null) {
            return 0;
        }
        return nota;
    }

    // 14. REPROGRAMAR SESIÓN DE CLASE
    public ArrayList<String> obtenerSesionesParaReprogramar(String idSeccion) {
        ArrayList<String> sesionesFormateadas = new ArrayList<>();
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            ArrayList<LocalDate> sesiones = seccion.getSesionesDeClase();
            for (int i = 0; i < sesiones.size(); i++) {
                sesionesFormateadas.add("Sesión " + (i + 1) + " - " + sesiones.get(i).format(formatter));
            }
        }
        return sesionesFormateadas;
    }

    public String reprogramarSesion(String idSeccion, int indiceSesion, LocalDate nuevaFecha) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) {
            return "Error: La sección no fue encontrada.";
        }

        ArrayList<LocalDate> sesiones = seccion.getSesionesDeClase();
        if (indiceSesion < 0 || indiceSesion >= sesiones.size()) {
            return "Error: El índice de la sesión seleccionada no es válido.";
        }

        // Reemplaza la fecha antigua por la nueva
        sesiones.set(indiceSesion, nuevaFecha);

        // Reordena la lista para mantener la coherencia cronológica
        Collections.sort(sesiones);

        return "Sesión reprogramada exitosamente.";
    }

    // 15. GESTIONAR PUNTOS ADICIONALES DIRECTOS
    public String asignarPuntosAdicionales(String idSeccion, String idEvaluacion, String codigoEstudiante, int puntosExtra, String motivo) {
        // a. Validar existencia de Sección y Estudiante
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";

        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El estudiante no existe.";

        // b. Validar matrícula
        if (!estaMatriculado(idSeccion, codigoEstudiante)) {
            return "Error: El estudiante no está matriculado en esta sección.";
        }

        // c. Validar que la evaluación exista en el curso
        if (!existeEvaluacionEnCurso(idSeccion, idEvaluacion)) {
            return "Error: La evaluación '" + idEvaluacion + "' no corresponde a este curso.";
        }

        // d. Validaciones de Negocio
        if (puntosExtra <= 0) {
            return "Error: Los puntos adicionales deben ser mayor a 0.";
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            return "Error: Debe especificar un motivo para el bono.";
        }

        // e. Acción (Suma)
        // REFACTOR: Los puntos adicionales ahora se suman a la NOTA ACADÉMICA, no a los puntos de participación.
        Integer notaActualInt = seccion.obtenerNota(codigoEstudiante, idEvaluacion);
        int notaActual = (notaActualInt == null) ? 0 : notaActualInt;

        // c. CÁLCULO y d. VALIDACIÓN DE TOPE
        int nuevaNotaCalculada = notaActual + puntosExtra;
        int nuevaNotaFinal = Math.min(nuevaNotaCalculada, 20); // La nota no puede exceder 20
        nuevaNotaFinal = Math.max(nuevaNotaFinal, 0);      // La nota no puede ser menor a 0

        // e. GUARDADO
        seccion.registrarNota(codigoEstudiante, idEvaluacion, nuevaNotaFinal);

        // f. Retornar mensaje de éxito
        return "✅ Bono aplicado correctamente a la nota de " + estudiante.getNombre() + ".\n\n" +
               "📊 DETALLE DE LA OPERACIÓN:\n" +
               "   • Nota Anterior:     " + notaActual + "\n" +
               "   • Bono Adicional:    +" + puntosExtra + "\n" +
               "   • -------------------------\n" +
               "   • NUEVA NOTA FINAL:  " + nuevaNotaFinal + " (Tope 20)\n\n" +
               "📝 Motivo: " + motivo;
    }

    // 16. GESTIONAR RECTIFICACIÓN DE NOTAS
    public String rectificarNota(String idSeccion, String idEvaluacion, String codigoEstudiante, int nuevaNota, String motivo) {
        // a. Validar existencia de Sección, Estudiante y Matrícula
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";

        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El estudiante no existe.";

        if (!estaMatriculado(idSeccion, codigoEstudiante)) {
            return "Error: El estudiante no está matriculado en esta sección.";
        }

        // b. Validar existencia de la evaluación en el curso
        if (!existeEvaluacionEnCurso(idSeccion, idEvaluacion)) {
            return "Error: La evaluación '" + idEvaluacion + "' no corresponde a este curso.";
        }

        // c. Validar rango de nota
        if (nuevaNota < 0 || nuevaNota > 20) {
            return "Error: La nueva nota debe estar entre 0 y 20.";
        }

        // d. Validar motivo
        if (motivo == null || motivo.trim().isEmpty()) {
            return "Error: Debe ingresar un motivo de rectificación obligatoriamente.";
        }

        // e. Lógica de Cambio
        Integer notaActual = seccion.obtenerNota(codigoEstudiante, idEvaluacion);
        if (notaActual == null) {
            return "Error: No existe una nota registrada previamente para rectificar. Use la opción 'Registrar Notas'.";
        }
        if (notaActual == nuevaNota) {
            return "Error: La nueva nota es igual a la actual. No se realizaron cambios.";
        }

        // f. Ejecución y Auditoría
        seccion.registrarNota(codigoEstudiante, idEvaluacion, nuevaNota); // Actualiza la nota
        String log = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) +
                     " | Alumno: " + codigoEstudiante + " (" + estudiante.getNombre() + ")" +
                     " | Eval: " + idEvaluacion.toUpperCase() +
                     " | Cambio: " + notaActual + " -> " + nuevaNota +
                     " | Motivo: " + motivo;
        seccion.agregarLogAuditoria(log);

        // g. Retornar mensaje de éxito
        return "Nota rectificada exitosamente.";
    }

    // 17. GENERAR ACTA DE NOTAS
    public String generarActaDeNotas(String idSeccion, String idEvaluacion) {
        // a. Validar existencia de Sección
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";

        // b. Validar que la evaluación exista en el curso
        if (!existeEvaluacionEnCurso(idSeccion, idEvaluacion)) {
            return "Error: La evaluación '" + idEvaluacion + "' no corresponde a este curso.";
        }

        // c. Obtener la lista de estudiantes matriculados
        ArrayList<NodoEstudiante> estudiantesMatriculados = seccion.getEstudiantesMatriculados();
        if (estudiantesMatriculados.isEmpty()) {
            return "Error: No hay estudiantes matriculados en esta sección para generar el acta.";
        }

        // d. Construcción del Reporte
        StringBuilder sb = new StringBuilder();
        sb.append("ACTA DE NOTAS - SECCIÓN: ").append(idSeccion).append(" - EVALUACIÓN: ").append(idEvaluacion.toUpperCase()).append("\n");
        sb.append("------------------------------------------------------------------------\n");
        sb.append(String.format("%-10s %-25s %-10s %-10s %-10s\n", "CÓDIGO", "ESTUDIANTE", "NOTA BASE", "PTOS EXTRA", "NOTA FINAL"));
        sb.append("------------------------------------------------------------------------\n");

        // e. Bucle de Cálculo
        for (NodoEstudiante estudiante : estudiantesMatriculados) {
            // Obtener "Nota Base"
            Integer base = seccion.obtenerNota(estudiante.getCodigo(), idEvaluacion);
            int notaBase = (base != null) ? base : 0; // Si no tiene nota, asume 0.

            // Obtener "Puntos Extra" (Participación + Bonos)
            Integer extra = seccion.obtenerPuntos(estudiante.getCodigo(), idEvaluacion);
            int puntosExtra = (extra != null) ? extra : 0;

            // Calcular "Nota Final"
            int suma = notaBase + puntosExtra;
            int notaFinal = Math.min(suma, 20); // Tope máximo de 20.

            // Agregar fila al reporte
            String nombreCorto = estudiante.getNombre().length() > 25 ? estudiante.getNombre().substring(0, 22) + "..." : estudiante.getNombre();
            sb.append(String.format("%-10s %-25s %-10d %-10d %-10d\n", estudiante.getCodigo(), nombreCorto, notaBase, puntosExtra, notaFinal));
        }

        // f. Retornar el String del reporte completo
        return sb.toString();
    }
}