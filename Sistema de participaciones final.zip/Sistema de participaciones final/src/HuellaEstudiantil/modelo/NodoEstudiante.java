package HuellaEstudiantil.modelo;

import java.util.HashMap;

public class NodoEstudiante {
    
    public static final int LIMITE_PARTICIPACIONES = 4;
    
    private String codigo;
    private String nombre;
    private String carrera; 
    private int ciclo;
    private HashMap<String, Integer> participacionesPorEvaluacion;
    private boolean activo;
    private NodoEstudiante sgte; 

    public NodoEstudiante(String codigo, String nombre, String carrera, int ciclo) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.carrera = carrera;
        this.ciclo = ciclo;
        this.participacionesPorEvaluacion = new HashMap<>();
        this.activo = true; // Por defecto, un nuevo estudiante está activo
        this.sgte = null;
    }

    // Getters y Setters
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCarrera() { return carrera; }
    public int getCiclo() { return ciclo; }

    public int getParticipaciones(String idEvaluacion) {
        return participacionesPorEvaluacion.getOrDefault(idEvaluacion.toUpperCase(), 0);
    }

    public void incrementarParticipacion(String idEvaluacion) {
        int actuales = getParticipaciones(idEvaluacion);
        participacionesPorEvaluacion.put(idEvaluacion.toUpperCase(), actuales + 1);
    }

    public void reiniciarParticipaciones(String idEvaluacion) {
        participacionesPorEvaluacion.put(idEvaluacion.toUpperCase(), 0);
    }

    public NodoEstudiante getSgte() { return sgte; }
    public void setSgte(NodoEstudiante sgte) { this.sgte = sgte; }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

}