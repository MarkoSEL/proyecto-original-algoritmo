package HuellaEstudiantil.modelo;

import java.time.LocalDate;

/**
 * Representa un nodo en la lista enlazada de Periodos Académicos.
 * Contiene la información de un periodo y la referencia al siguiente nodo.
 */
public class NodoPeriodo {

    private String id; // Formato: "YYYY-Nombre", ej. "2025-Marzo"
    private int anio;
    private String periodo; // "Verano", "Marzo" o "Agosto"
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private NodoPeriodo sgte;

    /**
     * Constructor para inicializar un nuevo periodo académico.
     *
     * @param id          Identificador único del periodo.
     * @param anio        Año del periodo.
     * @param periodo     Nombre del periodo ("Verano", "Marzo", "Agosto").
     * @param fechaInicio Fecha de inicio del periodo.
     * @param fechaFin    Fecha de fin del periodo.
     */
    public NodoPeriodo(String id, int anio, String periodo, LocalDate fechaInicio, LocalDate fechaFin) {
        this.id = id;
        this.anio = anio;
        this.periodo = periodo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.sgte = null; // Por defecto, el siguiente es nulo al crear un nuevo nodo.
    }

    // --- Getters y Setters ---

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public NodoPeriodo getSgte() {
        return sgte;
    }

    public void setSgte(NodoPeriodo sgte) {
        this.sgte = sgte;
    }
}