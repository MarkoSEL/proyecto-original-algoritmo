package HuellaEstudiantil.datos;

import HuellaEstudiantil.modelo.NodoPeriodo;
import java.util.ArrayList;

/**
 * Estructura de datos (Lista Enlazada Simple) para gestionar los periodos académicos.
 * Proporciona métodos para agregar, buscar y recuperar los periodos.
 */
public class ListaPeriodo {

    private NodoPeriodo inicio;

    public ListaPeriodo() {
        this.inicio = null;
    }

    /**
     * Agrega un nuevo nodo al final de la lista enlazada.
     * Si la lista está vacía, el nuevo nodo se convierte en el inicio.
     *
     * @param nuevo El NodoPeriodo a agregar.
     */
    public void agregarAlFinal(NodoPeriodo nuevo) {
        if (inicio == null) {
            inicio = nuevo;
        } else {
            NodoPeriodo actual = inicio;
            while (actual.getSgte() != null) {
                actual = actual.getSgte();
            }
            actual.setSgte(nuevo);
        }
    }

    /**
     * Realiza una búsqueda lineal para encontrar un periodo por su ID.
     *
     * @param id El identificador único del periodo a buscar.
     * @return El NodoPeriodo si se encuentra, de lo contrario, null.
     */
    public NodoPeriodo buscarPorId(String id) {
        NodoPeriodo actual = inicio;
        while (actual != null) {
            if (actual.getId().equalsIgnoreCase(id)) {
                return actual;
            }
            actual = actual.getSgte();
        }
        return null; // No se encontró el periodo
    }

    /**
     * Recorre la lista enlazada y devuelve todos los nodos en un ArrayList.
     * Esto es útil para desacoplar la estructura de datos interna de la capa de vista/controlador.
     *
     * @return Un ArrayList que contiene todos los NodoPeriodo de la lista.
     */
    public ArrayList<NodoPeriodo> getTodosComoArrayList() {
        ArrayList<NodoPeriodo> lista = new ArrayList<>();
        NodoPeriodo actual = inicio;
        while (actual != null) {
            lista.add(actual);
            actual = actual.getSgte();
        }
        return lista;
    }
}