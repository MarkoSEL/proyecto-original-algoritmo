package HuellaEstudiantil.vista;

import HuellaEstudiantil.controlador.Controlador;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import java.awt.GridLayout;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JScrollPane;

public class Vista {

    private Controlador controlador;

    public Vista() {
        this.controlador = new Controlador();
    }
    
    private DayOfWeek traducirDia(String diaEnEspanol) {
        switch (diaEnEspanol.trim().toUpperCase()) {
            case "LUNES": return DayOfWeek.MONDAY;
            case "MARTES": return DayOfWeek.TUESDAY;
            case "MIERCOLES":
            case "MIÉRCOLES": return DayOfWeek.WEDNESDAY;
            case "JUEVES": return DayOfWeek.THURSDAY;
            case "VIERNES": return DayOfWeek.FRIDAY;
            case "SABADO":
            case "SÁBADO": return DayOfWeek.SATURDAY;
            case "DOMINGO": return DayOfWeek.SUNDAY;
            default: return null; 
        }
    }

    public void mostrarMenu() {
        String menu = "SISTEMA DE PARTICIPACIONES 'HUELLA ESTUDIANTIL'\n\n"
                + "--- MÓDULO DE CONFIGURACIÓN ACADÉMICA ---\n"
                + "1. Gestionar Periodos Académicos\n"
                + "2. Registrar Curso\n"
                + "3. Definir Estructura de Evaluaciones por Curso\n"
                + "4. Registrar Docente\n"
                + "5. Registrar Sección\n"
                + "6. Generar Sesiones de Clase\n\n"
                + "--- MÓDULO DE REGISTRO Y PROCESAMIENTO DE PARTICIPACIONES ---\n"
                + "7. Registrar Estudiante\n"
                + "8. Registrar Participación\n"
                + "9. Procesar Participaciones\n"
                + "10. Ajustar Puntos Manualmente\n" 
                + "11. Inhabilitar/Habilitar Estudiante\n"
                + "12. Consultar Historial de Puntos\n\n"
                + "--- MÓDULO DE ADMINISTRACIÓN Y CALIFICACIONES ---\n"
                + "13. Matricular Estudiante en Sección\n\n"
                + "0. Salir\n"
                + "Ingrese una opción:";

        int opcion = -1;
        do {
            try {
                String input = JOptionPane.showInputDialog(null, menu);
                if (input == null) {
                    opcion = 0;
                    break;
                }
                opcion = Integer.parseInt(input);

                switch (opcion) {
                    case 1: gestionarRegistrarPeriodo(); break; // Mantenido
                    case 2: gestionarRegistrarCurso(); break; // Mantenido
                    case 3: gestionarDefinirEvaluacion(); break; // Antes 6
                    case 4: gestionarRegistrarDocente(); break; // Antes 3
                    case 5: gestionarRegistrarSeccion(); break; // Mantenido
                    case 6: gestionarGenerarSesiones(); break; // Antes 7
                    case 7: gestionarRegistrarEstudiante(); break; // Antes 4
                    case 8: gestionarRegistroParticipacion(); break; // Antes 9
                    case 9: gestionarProcesarParticipaciones(); break; // Antes 10
                    case 10: gestionarAjusteManual(); break; // Antes 11
                    case 11: gestionarEstadoEstudiante(); break;
                    case 12: gestionarConsultarHistorial(); break;
                    case 13: gestionarMatricula(); break;
                    case 0: JOptionPane.showMessageDialog(null, "Saliendo..."); break;
                    default: JOptionPane.showMessageDialog(null, "Opción no válida.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese solo números.");
            }
        } while (opcion != 0);
    }
    
    // --- GESTIÓN DE REGISTROS (MEJORA UX) ---

    private void gestionarRegistrarPeriodo() { // REFACTORIZADO A FLUJO SECUENCIAL
        int anio;
        try {
            // 1. Pedir Año y validar que sea > 2025
            String anioStr = JOptionPane.showInputDialog("Ingrese Año del Periodo Académico:");
            if (anioStr == null) return; // Usuario canceló
            anio = Integer.parseInt(anioStr);
            if (anio < 2025) {
                JOptionPane.showMessageDialog(null, "Error: El año debe ser 2025 o posterior.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Ingrese un año válido.");
            return;
        }

        // 2. Mostrar ComboBox con opciones de periodo
        String[] opcionesPeriodo = {"Verano", "Marzo", "Agosto"};
        String periodoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el periodo:",
                "Selección de Periodo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesPeriodo,
                opcionesPeriodo[0]);

        if (periodoSeleccionado == null) return; // Usuario canceló

        // 3. Generar ID temporal y validar existencia
        String idTemporal = anio + "-" + periodoSeleccionado;
        if (controlador.existePeriodo(idTemporal)) {
            JOptionPane.showMessageDialog(null, "Error: El periodo '" + idTemporal + "' ya existe.");
            return;
        }

        // 4. BLOQUE FECHA INICIO (Validación Estricta y Secuencial)
        LocalDate fechaInicio;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            String fechaInicioStr = JOptionPane.showInputDialog("Ingrese Fecha de Inicio (dd/mm/yyyy):");
            if (fechaInicioStr == null || fechaInicioStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de inicio es obligatoria.");
                return;
            }
            fechaInicio = LocalDate.parse(fechaInicioStr, formatter);
            
            if (fechaInicio.getYear() != anio) {
                JOptionPane.showMessageDialog(null, "Error: El año de la fecha de inicio (" + fechaInicio.getYear() + ") no corresponde al Año Académico indicado (" + anio + ").");
                return;
            }
            
            // NUEVA VALIDACIÓN (Fail-Fast): Verificar si la fecha de inicio ya está ocupada.
            if (controlador.fechaEstaOcupada(fechaInicio)) {
                JOptionPane.showMessageDialog(null, "Error: La fecha " + fechaInicio.format(formatter) + " ya está ocupada por otro periodo académico registrado.");
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: El formato de la fecha de inicio debe ser dd/mm/yyyy.");
            return;
        }

        // 5. BLOQUE FECHA FIN (Solo se ejecuta si el paso anterior fue exitoso)
        LocalDate fechaFin;
        try {
            String fechaFinStr = JOptionPane.showInputDialog("Ingrese Fecha de Fin (dd/mm/yyyy):");
            if (fechaFinStr == null || fechaFinStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de fin es obligatoria.");
                return;
            }
            fechaFin = LocalDate.parse(fechaFinStr, formatter);

            if (fechaFin.isBefore(fechaInicio)) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de fin no puede ser anterior a la fecha de inicio.");
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: El formato de la fecha de fin debe ser dd/mm/yyyy.");
            return;
        }

        // a. Calcular semanas calendario (redondeando hacia arriba) para la advertencia
        long diasParaAdvertencia = ChronoUnit.DAYS.between(fechaInicio, fechaFin) + 1;
        long semanasCalculadas = (long) Math.ceil(diasParaAdvertencia / 7.0);
        
        // b. Definir límite máximo exacto
        int semanasLimite = periodoSeleccionado.equalsIgnoreCase("Verano") ? 9 : 18;

        // c. Validación Estricta: Si supera el límite
        if (semanasCalculadas > semanasLimite) {
            String mensaje = "ADVERTENCIA DE DURACIÓN EXCESIVA:\n\n" +
                             "El periodo '" + periodoSeleccionado + "' no debería exceder las " + semanasLimite + " semanas.\n" +
                             "Sin embargo, las fechas ingresadas ocupan " + semanasCalculadas + " semanas calendario.\n\n" +
                             "¿Está seguro de que desea registrar este periodo así?";
                             
            int respuesta = JOptionPane.showConfirmDialog(null,
                    mensaje, "Verificación de Límites", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            
            if (respuesta != JOptionPane.YES_OPTION) {
                return; // Cancelar y volver al menú
            }
        }

        // 6. LLAMADA FINAL (Solo si todas las validaciones pasaron)
        String resultado = controlador.registrarPeriodo(anio, periodoSeleccionado, fechaInicio, fechaFin);
        
        // Corregir el cálculo de semanas para el mensaje de éxito para que coincida con la generación real
        long diasTotales = ChronoUnit.DAYS.between(fechaInicio, fechaFin) + 1;
        long semanasCalendario = (long) Math.ceil(diasTotales / 7.0);

        JOptionPane.showMessageDialog(null, resultado + "\nDuración aproximada: " + semanasCalendario + " semanas calendario.");
    }

    private void gestionarRegistrarCurso() {
        // 1. Pedir SOLO Código primero
        String codigo = JOptionPane.showInputDialog("Ingrese Código del Curso (ej. CS101):");
        if (codigo == null) return; // Usuario canceló
        if (codigo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El código del curso es obligatorio.");
            return;
        }

        // 2. Validar INMEDIATAMENTE (Fail-Fast)
        if (controlador.existeCurso(codigo)) {
            JOptionPane.showMessageDialog(null, "Error: El código '" + codigo + "' ya existe en el sistema.");
            return; // Detener aquí
        }

        // 3. Pedir el resto SOLO si no existe
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Curso:");
        if (nombre == null) return; // Usuario canceló
        if (nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre del curso es obligatorio.");
            return;
        }

        // 4. Usar ComboBox para seleccionar el Tipo de Curso
        String[] opcionesTipo = {"Presencial", "Remoto", "Virtual"};
        String tipoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el tipo de curso:",
                "Selección de Tipo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesTipo,
                opcionesTipo[0]);

        // VALIDACIÓN: Si el usuario presiona Cancelar, el método termina.
        if (tipoSeleccionado == null) return;
        
        // 5. Pedir y validar la Capacidad
        try {
            String capacidadStr = JOptionPane.showInputDialog("Ingrese Capacidad Máxima:");
            if (capacidadStr == null) return; // Usuario canceló
            if (capacidadStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: La capacidad es obligatoria.");
                return;
            }
            int capacidad = Integer.parseInt(capacidadStr);
            if (capacidad <= 0) {
                JOptionPane.showMessageDialog(null, "Error: La capacidad debe ser un número positivo.");
                return;
            }
            // Llamar al método de Controlador que ahora solo CREA
            JOptionPane.showMessageDialog(null, controlador.registrarCurso(codigo, nombre, tipoSeleccionado, capacidad));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: La capacidad debe ser un número válido.");
        }
    }

    private void gestionarRegistrarDocente() {
        // 1. Pedir ID
        String id = JOptionPane.showInputDialog("Ingrese ID del Docente (ej. D001):");
        if (id == null) return; // Usuario canceló
        if (id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El ID del docente es obligatorio.");
            return;
        }
        
        // 2. Validar (Fail-Fast)
        if (controlador.existeDocente(id)) {
            JOptionPane.showMessageDialog(null, "Error: El ID '" + id + "' ya existe.");
            return;
        }

        // 3. Pedir Nombre
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Docente:");
        if (nombre == null) return; // Usuario canceló
        if (nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre del docente es obligatorio.");
            return;
        }
        
        JOptionPane.showMessageDialog(null, controlador.registrarDocente(id, nombre));
    }

    private void gestionarRegistrarEstudiante() {
        // PASO 1: Pedir Nombre Completo
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre Completo del Estudiante:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre es obligatorio.");
            return;
        }

        // PASO 2: Pedir Carrera
        String[] opcionesCarrera = {"Software", "Sistemas", "Redes"};
        String carrera = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione la carrera del estudiante:",
                "Selección de Carrera",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesCarrera,
                opcionesCarrera[0]);

        // Si el usuario presiona "Cancelar", el resultado es null.
        if (carrera == null) return;

        // PASO C: VALIDACIÓN DE NEGOCIO (Combinación Nombre + Carrera)
        if (controlador.existeEstudiante(nombre, carrera)) {
            JOptionPane.showMessageDialog(null, "Error: El estudiante '" + nombre.trim() + "' ya está registrado en la carrera de '" + carrera.trim() + "'.");
            return;
        }

        // PASO 3: Pedir Ciclo (Solo si las validaciones anteriores pasaron)
        int ciclo = -1;
        JPanel panelCiclo = new JPanel(new GridLayout(0, 2)); // Layout para 2 columnas
        ButtonGroup grupoCiclos = new ButtonGroup();
        JRadioButton[] radios = new JRadioButton[10];

        for (int i = 0; i < 10; i++) {
            radios[i] = new JRadioButton("Ciclo " + (i + 1));
            radios[i].setActionCommand(String.valueOf(i + 1)); // Guardar el número del ciclo
            grupoCiclos.add(radios[i]);
            panelCiclo.add(radios[i]);
        }
        radios[0].setSelected(true); // Pre-seleccionar el primer ciclo

        int result = JOptionPane.showConfirmDialog(null, panelCiclo, "Seleccione el Ciclo", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            return; // Usuario canceló
        }

        // Encontrar el ciclo seleccionado
        String cicloSeleccionado = grupoCiclos.getSelection().getActionCommand();
        if (cicloSeleccionado != null) {
            ciclo = Integer.parseInt(cicloSeleccionado);
        } else {
            // Esto no debería ocurrir si pre-seleccionamos uno, pero es una buena práctica de seguridad
            JOptionPane.showMessageDialog(null, "Error: Debe seleccionar un ciclo.");
            return;
        }

        // FINAL: Llamar al controlador solo si todas las validaciones pasaron
        JOptionPane.showMessageDialog(null, controlador.registrarEstudiante(nombre, carrera, ciclo));
    }
    
    private void gestionarRegistrarSeccion() {
        // 1. SELECCIONAR CURSO (ComboBox)
        ArrayList<String> cursos = controlador.obtenerCursosFormateados();
        if (cursos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay cursos registrados. Registre uno primero.");
            return;
        }
        String cursoSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el Curso:",
                "Registro de Sección - Paso 1", JOptionPane.QUESTION_MESSAGE, null, cursos.toArray(), cursos.get(0));
        if (cursoSeleccionado == null) return; // Usuario canceló
        String codigoCurso = cursoSeleccionado.split(" - ")[0];

        // 2. SELECCIONAR DOCENTE (ComboBox)
        ArrayList<String> docentes = controlador.obtenerDocentesFormateados();
        if (docentes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay docentes registrados. Registre uno primero.");
            return;
        }
        String docenteSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el Docente:",
                "Registro de Sección - Paso 2", JOptionPane.QUESTION_MESSAGE, null, docentes.toArray(), docentes.get(0));
        if (docenteSeleccionado == null) return; // Usuario canceló
        String idDocente = docenteSeleccionado.split(" - ")[0];

        // 3. Obtener y mostrar los periodos disponibles en un ComboBox
        ArrayList<String> idsPeriodos = controlador.obtenerIDsPeriodos();
        if (idsPeriodos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay periodos académicos registrados. Por favor, registre un periodo primero.");
            return;
        }

        String periodoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el Periodo Académico:",
                "Registro de Sección",
                JOptionPane.QUESTION_MESSAGE,
                null,
                idsPeriodos.toArray(), // Convertir ArrayList a Array
                idsPeriodos.get(0)
        );

        if (periodoSeleccionado == null) {
            return; // El usuario canceló la selección
        }

        // 4. Llamar al controlador con el periodo seleccionado
        JOptionPane.showMessageDialog(null, controlador.registrarSeccion(codigoCurso, idDocente, periodoSeleccionado));
    }
    
    // --- GESTIÓN DE PROCESOS (Sin cambios en lógica) ---
    
    private void gestionarGenerarSesiones() {
        // 1. SELECCIONAR SECCIÓN (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas. Registre una primero.");
            return;
        }
        String seccionSeleccionada = (String) JOptionPane.showInputDialog(null, "Seleccione la Sección para generar sesiones:",
                "Generar Sesiones de Clase", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(), secciones.get(0));

        if (seccionSeleccionada == null) return; // Usuario canceló
        
        String idSec = seccionSeleccionada.split(" - ")[0];

        // 2. Crear y mostrar panel con CheckBoxes para los días de la semana
        JPanel panelDias = new JPanel(new GridLayout(0, 1));
        JCheckBox chkLunes = new JCheckBox("Lunes");
        JCheckBox chkMartes = new JCheckBox("Martes");
        JCheckBox chkMiercoles = new JCheckBox("Miércoles");
        JCheckBox chkJueves = new JCheckBox("Jueves");
        JCheckBox chkViernes = new JCheckBox("Viernes");
        JCheckBox chkSabado = new JCheckBox("Sábado");
        panelDias.add(chkLunes);
        panelDias.add(chkMartes);
        panelDias.add(chkMiercoles);
        panelDias.add(chkJueves);
        panelDias.add(chkViernes);
        panelDias.add(chkSabado);

        int result = JOptionPane.showConfirmDialog(null, panelDias, "Seleccione los Días de Clase", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return; // Usuario canceló

        // 3. Recopilar los días seleccionados y llamar al controlador
        ArrayList<DayOfWeek> diasList = new ArrayList<>();
        if (chkLunes.isSelected()) diasList.add(DayOfWeek.MONDAY);
        if (chkMartes.isSelected()) diasList.add(DayOfWeek.TUESDAY);
        if (chkMiercoles.isSelected()) diasList.add(DayOfWeek.WEDNESDAY);
        if (chkJueves.isSelected()) diasList.add(DayOfWeek.THURSDAY);
        if (chkViernes.isSelected()) diasList.add(DayOfWeek.FRIDAY);
        if (chkSabado.isSelected()) diasList.add(DayOfWeek.SATURDAY);

        if (diasList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Debe seleccionar al menos un día de clase.");
            return;
        }
        
        try {
            mostrarScroll(controlador.generarSesiones(idSec, diasList.toArray(new DayOfWeek[0])), "Calendario de Sesiones Generado");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error inesperado al generar las sesiones: " + e.getMessage());
        }
    }

    private void gestionarMatricula() {
        // PASO 1: SELECCIONAR SECCIÓN (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas. Registre una primero.");
            return;
        }
        String idSeccionSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione la Sección:",
                "Matricular Estudiante - Paso 1", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(), secciones.get(0));

        if (idSeccionSeleccionado == null) return; // Usuario canceló

        // PASO 2: SELECCIONAR ESTUDIANTES (CheckBoxes)
        ArrayList<String> estudiantes = controlador.obtenerEstudiantesParaMatricula();
        if (estudiantes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay estudiantes registrados en el sistema.");
            return;
        }

        // REFACTOR UX: Usar BoxLayout para evitar que los checkboxes se estiren.
        // Se crea un panel principal que contendrá los checkboxes alineados verticalmente.
        JPanel panelContenedor = new JPanel();
        panelContenedor.setLayout(new javax.swing.BoxLayout(panelContenedor, javax.swing.BoxLayout.Y_AXIS));

        JCheckBox[] checkboxes = new JCheckBox[estudiantes.size()];
        for (int i = 0; i < estudiantes.size(); i++) {
            checkboxes[i] = new JCheckBox(estudiantes.get(i));
            // Cada checkbox se alinea a la izquierda para una apariencia limpia.
            checkboxes[i].setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            panelContenedor.add(checkboxes[i]);
        }

        // Usar un JScrollPane para manejar listas largas de estudiantes
        JScrollPane scrollPane = new JScrollPane(panelContenedor);
        scrollPane.setPreferredSize(new java.awt.Dimension(400, 300));

        int result = JOptionPane.showConfirmDialog(null, scrollPane, "Seleccione los Estudiantes a Matricular", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return; // Usuario canceló

        // Recopilar los códigos de los estudiantes seleccionados
        ArrayList<String> codigosSeleccionados = new ArrayList<>();
        for (JCheckBox chk : checkboxes) {
            if (chk.isSelected()) {
                String codigo = chk.getText().split(" - ")[0];
                codigosSeleccionados.add(codigo);
            }
        }

        if (codigosSeleccionados.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se seleccionó ningún estudiante para matricular.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // FINAL: Llamar al controlador
        String resumenMatricula = controlador.matricularMultiplesEstudiantes(codigosSeleccionados, idSeccionSeleccionado);
        mostrarScroll(resumenMatricula, "Resumen de Matrícula");
    }

    private void gestionarRegistroParticipacion() {
        // PASO 1: SELECCIONAR SECCIÓN (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas. Registre una primero.");
            return;
        }
        String idSeccion = (String) JOptionPane.showInputDialog(null, "Seleccione la Sección:",
                "Registrar Participación - Paso 1", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(), secciones.get(0));

        if (idSeccion == null) return; // Usuario canceló

        // PASO 2: SELECCIONAR ESTUDIANTE (ComboBox)
        ArrayList<String> estudiantes = controlador.obtenerEstudiantesDeSeccion(idSeccion);
        if (estudiantes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay alumnos matriculados en esta sección.");
            return;
        }
        String estudianteSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el Estudiante:",
                "Selección de Estudiante", JOptionPane.QUESTION_MESSAGE, null, estudiantes.toArray(), estudiantes.get(0));
        if (estudianteSeleccionado == null) return; // Usuario canceló

        // Extraer el código del estudiante del string seleccionado
        String codigoEstudiante = estudianteSeleccionado.split(" - ")[0];

        // PASO 3: Pedir y validar Evaluación
        ArrayList<String> evaluaciones = controlador.obtenerEvaluacionesDeCurso(idSeccion);
        if (evaluaciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No se han definido evaluaciones para el curso de esta sección.\nUse la opción 3 del menú primero.");
            return;
        }

        JPanel panelEvaluaciones = new JPanel(new GridLayout(0, 1));
        ButtonGroup grupoEvaluaciones = new ButtonGroup();
        JRadioButton[] radiosEval = new JRadioButton[evaluaciones.size()];

        for (int i = 0; i < evaluaciones.size(); i++) {
            String nombreEval = evaluaciones.get(i);
            radiosEval[i] = new JRadioButton(nombreEval);
            radiosEval[i].setActionCommand(nombreEval);
            grupoEvaluaciones.add(radiosEval[i]);
            panelEvaluaciones.add(radiosEval[i]);
        }
        radiosEval[0].setSelected(true); // Pre-seleccionar la primera

        int resultEval = JOptionPane.showConfirmDialog(null, panelEvaluaciones, "Seleccione la Evaluación", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (resultEval != JOptionPane.OK_OPTION) return; // Usuario canceló

        String nombreEvaluacion = grupoEvaluaciones.getSelection().getActionCommand();

        // PASO 4: SELECCIONAR SEMANA (Radio Buttons)
        int semanaNum;
        int totalSemanas = controlador.obtenerSemanasDeSeccion(idSeccion);
        if (totalSemanas == 0) {
            JOptionPane.showMessageDialog(null, "Error: No se pudo determinar la duración del periodo para esta sección.");
            return;
        }

        JPanel panelSemanas = new JPanel(new GridLayout(0, 3)); // 3 columnas
        ButtonGroup grupoSemanas = new ButtonGroup();
        JRadioButton[] radios = new JRadioButton[totalSemanas];

        for (int i = 0; i < totalSemanas; i++) {
            radios[i] = new JRadioButton("Semana " + (i + 1));
            radios[i].setActionCommand(String.valueOf(i + 1));
            grupoSemanas.add(radios[i]);
            panelSemanas.add(radios[i]);
        }
        radios[0].setSelected(true); // Pre-seleccionar la primera semana

        int result = JOptionPane.showConfirmDialog(null, panelSemanas, "Seleccione la Semana", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return; // Usuario canceló

        semanaNum = Integer.parseInt(grupoSemanas.getSelection().getActionCommand());

        // PASO 5: Seleccionar Sesión (Lógica inteligente)
        ArrayList<String> sesionesFiltradas = controlador.obtenerSesionesPorSemana(idSeccion, semanaNum);
        String sesionSeleccionada;

        if (sesionesFiltradas.isEmpty()) {
            // CASO A: Lista vacía
            JOptionPane.showMessageDialog(null, "Error: No hay sesiones registradas en la semana " + semanaNum + " (o es feriado).");
            return;
        } else if (sesionesFiltradas.size() == 1) {
            // CASO B: Sesión única
            sesionSeleccionada = sesionesFiltradas.get(0);
            JOptionPane.showMessageDialog(null, "Sesión única detectada: " + sesionSeleccionada + ". Seleccionada automáticamente.");
        } else {
            // CASO C: Múltiples sesiones, mostrar ComboBox
            sesionSeleccionada = (String) JOptionPane.showInputDialog(null, "Seleccione la fecha de la sesión para la semana " + semanaNum + ":",
                    "Selección de Sesión", JOptionPane.QUESTION_MESSAGE, null, sesionesFiltradas.toArray(), sesionesFiltradas.get(0));
            if (sesionSeleccionada == null) return; // Cancelado
        }

        // FINAL: Llamar al controlador con todos los datos validados
        JOptionPane.showMessageDialog(null, controlador.registrarParticipacion(idSeccion, nombreEvaluacion, "Semana " + semanaNum, sesionSeleccionada, codigoEstudiante));
    }

    private void gestionarProcesarParticipaciones() {
        // 1. SELECCIONAR SECCIÓN (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas.");
            return;
        }
        String idSeccion = (String) JOptionPane.showInputDialog(null, "Seleccione la Sección a procesar:",
                "Procesar Participaciones - Paso 1", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(), secciones.get(0));
        if (idSeccion == null) return; // Usuario canceló

        // 2. SELECCIONAR EVALUACIÓN (ComboBox)
        ArrayList<String> evaluaciones = controlador.obtenerEvaluacionesDeCurso(idSeccion);
        if (evaluaciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay evaluaciones definidas para el curso de esta sección.");
            return;
        }
        String evaluacion = (String) JOptionPane.showInputDialog(null, "Seleccione la Evaluación a procesar:",
                "Procesar Participaciones - Paso 2", JOptionPane.QUESTION_MESSAGE, null, evaluaciones.toArray(), evaluaciones.get(0));
        if (evaluacion == null) return; // Usuario canceló

        mostrarScroll(controlador.procesarParticipaciones(idSeccion, evaluacion), "Resultado del Procesamiento");
    }

    private void gestionarDefinirEvaluacion() {
        // PASO 1: SELECCIONAR CURSO (ComboBox)
        ArrayList<String> cursos = controlador.obtenerCursosFormateados();
        if (cursos == null || cursos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay cursos registrados. Registre uno primero.");
            return;
        }
        String cursoSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el Curso para definirle evaluaciones:",
                "Definir Evaluaciones", JOptionPane.QUESTION_MESSAGE, null, cursos.toArray(), cursos.get(0));
        if (cursoSeleccionado == null) return; // Usuario canceló
        String codigoCurso = cursoSeleccionado.split(" - ")[0];

        // PASO 2: Crear y mostrar panel con CheckBoxes para las evaluaciones estándar
        JPanel panelEvaluaciones = new JPanel(new GridLayout(0, 2)); // 2 columnas
        JCheckBox[] checkboxes = {
            new JCheckBox("PC1"), new JCheckBox("PC2"),
            new JCheckBox("PC3"), new JCheckBox("Examen Final"),
            new JCheckBox("Laboratorio 1"), new JCheckBox("Laboratorio 2"),
            new JCheckBox("Laboratorio 3"), new JCheckBox("Laboratorio 4"),
            new JCheckBox("Avance de proyecto final 1"), new JCheckBox("Avance de proyecto final 2"),
            new JCheckBox("Avance de proyecto final 3"), new JCheckBox("Proyecto Final")
        };

        for (JCheckBox chk : checkboxes) {
            panelEvaluaciones.add(chk);
        }

        int result = JOptionPane.showConfirmDialog(null, panelEvaluaciones, "Seleccione Evaluaciones para " + codigoCurso, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            return; // Usuario canceló
        }

        // PASO 3: Procesar la selección
        int agregados = 0;
        for (JCheckBox chk : checkboxes) {
            if (chk.isSelected()) {
                // Llamamos al controlador pero ignoramos el mensaje individual
                controlador.definirEvaluacion(codigoCurso, chk.getText());
                agregados++;
            }
        }

        // PASO 4: Feedback Final
        if (agregados > 0) {
            JOptionPane.showMessageDialog(null, "Se han agregado " + agregados + " evaluaciones al curso " + codigoCurso + " exitosamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se seleccionó ninguna evaluación para agregar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void gestionarAjusteManual() {
        // 1. SELECCIONAR SECCIÓN (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas.");
            return;
        }
        String seccionSeleccionada = (String) JOptionPane.showInputDialog(null, "Seleccione la Sección:", "Ajuste Manual - Paso 1", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(), secciones.get(0));
        if (seccionSeleccionada == null) return;

        // Extraer solo el ID
        String idSeccion = seccionSeleccionada.split(" - ")[0];

        // 2. SELECCIONAR ESTUDIANTE (ComboBox)
        ArrayList<String> estudiantes = controlador.obtenerEstudiantesDeSeccion(idSeccion);
        if (estudiantes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay estudiantes matriculados en esta sección.");
            return;
        }
        String estudianteSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione el Estudiante:", "Ajuste Manual - Paso 2", JOptionPane.QUESTION_MESSAGE, null, estudiantes.toArray(), estudiantes.get(0));
        if (estudianteSeleccionado == null) return;
        String codigoEstudiante = estudianteSeleccionado.split(" - ")[0];

        // 3. SELECCIONAR EVALUACIÓN (ComboBox)
        ArrayList<String> evaluaciones = controlador.obtenerEvaluacionesDeCurso(idSeccion);
        if (evaluaciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay evaluaciones definidas para el curso de esta sección.");
            return;
        }
        String evaluacion = (String) JOptionPane.showInputDialog(null, "Seleccione la Evaluación a ajustar:", "Ajuste Manual - Paso 3", JOptionPane.QUESTION_MESSAGE, null, evaluaciones.toArray(), evaluaciones.get(0));
        if (evaluacion == null) return;

        // 4. Pedir el nuevo puntaje
        // REFACTORIZACIÓN UX: Usar RadioButtons en lugar de input de texto.
        
        // A. Consultar Puntaje Actual
        Integer puntajeActualInt = controlador.consultarPuntajeActual(idSeccion, evaluacion, codigoEstudiante);
        int puntajeActual = (puntajeActualInt == null) ? 0 : puntajeActualInt;

        // B. Crear Panel de Selección
        JPanel panelAjuste = new JPanel(new java.awt.GridLayout(0, 1));
        panelAjuste.add(new javax.swing.JLabel("Estudiante: " + estudianteSeleccionado));
        panelAjuste.add(new javax.swing.JLabel("Puntaje actual: " + puntajeActual + " puntos."));
        panelAjuste.add(new javax.swing.JLabel(" ")); // Espaciador
        panelAjuste.add(new javax.swing.JLabel("Seleccione el nuevo puntaje ajustado:"));

        // C. Crear RadioButtons
        ButtonGroup grupoPuntajes = new ButtonGroup();
        JRadioButton radio0 = new JRadioButton("0 Puntos");
        radio0.setActionCommand("0");
        JRadioButton radio1 = new JRadioButton("1 Punto");
        radio1.setActionCommand("1");
        JRadioButton radio2 = new JRadioButton("2 Puntos");
        radio2.setActionCommand("2");
        JRadioButton radio3 = new JRadioButton("3 Puntos");
        radio3.setActionCommand("3");

        grupoPuntajes.add(radio0);
        grupoPuntajes.add(radio1);
        grupoPuntajes.add(radio2);
        grupoPuntajes.add(radio3);

        panelAjuste.add(radio0);
        panelAjuste.add(radio1);
        panelAjuste.add(radio2);
        panelAjuste.add(radio3);

        // Pre-seleccionar el puntaje actual
        if (puntajeActual == 1) radio1.setSelected(true);
        else if (puntajeActual == 2) radio2.setSelected(true);
        else if (puntajeActual == 3) radio3.setSelected(true);
        else radio0.setSelected(true);

        // D. Mostrar Diálogo
        int result = JOptionPane.showConfirmDialog(null, panelAjuste, "Ajuste Manual de Puntaje", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        // E. Procesar Respuesta
        if (result == JOptionPane.OK_OPTION) {
            String puntajeSeleccionadoStr = grupoPuntajes.getSelection().getActionCommand();
            int nuevoPuntaje = Integer.parseInt(puntajeSeleccionadoStr);
            
            String mensajeResultado = controlador.ajustarParticipaciones(idSeccion, evaluacion, codigoEstudiante, nuevoPuntaje);
            JOptionPane.showMessageDialog(null, mensajeResultado);
        }
    }
    
    private void mostrarScroll(String texto, String titulo) {
        javax.swing.JTextArea ta = new javax.swing.JTextArea(texto);
        ta.setEditable(false);
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(ta);
        sp.setPreferredSize(new java.awt.Dimension(500, 400));
        JOptionPane.showMessageDialog(null, sp, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    private void gestionarEstadoEstudiante() {
        ArrayList<String> estudiantes = controlador.obtenerEstudiantesConEstado();
        if (estudiantes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay estudiantes registrados en el sistema.");
            return;
        }

        String estudianteSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione un estudiante para cambiar su estado:",
                "Inhabilitar/Habilitar Estudiante", JOptionPane.QUESTION_MESSAGE, null, estudiantes.toArray(new String[0]), estudiantes.get(0));

        if (estudianteSeleccionado == null) {
            return; // El usuario canceló
        }

        String codigoEstudiante = estudianteSeleccionado.split(" - ")[0];

        int confirmacion = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de que desea cambiar el estado de este estudiante?",
                "Confirmar Cambio de Estado",
                JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            String resultado = controlador.cambiarEstadoEstudiante(codigoEstudiante);
            JOptionPane.showMessageDialog(null, resultado);
        }
    }

    private void gestionarConsultarHistorial() {
        // PASO 1: Seleccionar Sección (ComboBox)
        ArrayList<String> secciones = controlador.obtenerIDsTodasLasSecciones();
        if (secciones.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay secciones registradas en el sistema.");
            return;
        }
        String idSeccion = (String) JOptionPane.showInputDialog(null, "Seleccione una sección:",
                "Consultar Historial", JOptionPane.QUESTION_MESSAGE, null, secciones.toArray(new String[0]), secciones.get(0));
        if (idSeccion == null) {
            return; // El usuario canceló
        }

        // PASO 2: Seleccionar Estudiante (ComboBox)
        ArrayList<String> estudiantes = controlador.obtenerEstudiantesDeSeccion(idSeccion);
        if (estudiantes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay estudiantes matriculados en esta sección.");
            return;
        }
        String estudianteSeleccionado = (String) JOptionPane.showInputDialog(null, "Seleccione un estudiante:",
                "Consultar Historial", JOptionPane.QUESTION_MESSAGE, null, estudiantes.toArray(new String[0]), estudiantes.get(0));
        if (estudianteSeleccionado == null) {
            return; // El usuario canceló
        }

        // Extraer el código del estudiante del string "Código - Nombre"
        String codigoEstudiante = estudianteSeleccionado.split(" - ")[0];

        // PASO 3: Mostrar Resultado
        String resultado = controlador.consultarHistorial(idSeccion, codigoEstudiante);

        if (resultado.startsWith("Error:")) {
            JOptionPane.showMessageDialog(null, resultado, "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            mostrarScroll(resultado, "Historial de Puntos");
        }
    }

}