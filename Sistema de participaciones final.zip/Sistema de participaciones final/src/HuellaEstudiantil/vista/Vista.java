package HuellaEstudiantil.vista;

import HuellaEstudiantil.controlador.Controlador;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Vista {

    private Controlador controlador;

    public Vista() {
        this.controlador = new Controlador();
    }
    
    private DayOfWeek traducirDia(String diaEnEspanol) {
        switch (diaEnEspanol.trim().toUpperCase()) {
            case "LUNES": return DayOfWeek.MONDAY;
            case "MARTES": return DayOfWeek.TUESDAY;
            case "MIERCOLES":
            case "MIÉRCOLES": return DayOfWeek.WEDNESDAY;
            case "JUEVES": return DayOfWeek.THURSDAY;
            case "VIERNES": return DayOfWeek.FRIDAY;
            case "SABADO":
            case "SÁBADO": return DayOfWeek.SATURDAY;
            case "DOMINGO": return DayOfWeek.SUNDAY;
            default: return null; 
        }
    }

    public void mostrarMenu() {
        String menu = "SISTEMA DE PARTICIPACIONES 'HUELLA ESTUDIANTIL'\n\n"
                + "--- MÓDULO DE CONFIGURACIÓN ACADÉMICA ---\n"
                + "1. Gestionar Periodos Académicos\n"
                + "2. Registrar Curso\n"
                + "3. Definir Estructura de Evaluaciones por Curso\n"
                + "4. Registrar Docente\n"
                + "5. Registrar Sección\n"
                + "6. Generar Sesiones de Clase\n\n"
                + "--- MÓDULO DE REGISTRO Y PROCESAMIENTO DE PARTICIPACIONES ---\n"
                + "7. Registrar Estudiante\n"
                + "8. Registrar Participación\n"
                + "9. Procesar Participaciones\n"
                + "10. Ajustar Puntos Manualmente\n\n"
                + "--- MÓDULO DE ADMINISTRACIÓN Y CALIFICACIONES ---\n"
                + "11. Matricular Estudiante en Sección\n\n"
                + "0. Salir\n\n"
                + "Ingrese una opción:";

        int opcion = -1;
        do {
            try {
                String input = JOptionPane.showInputDialog(null, menu);
                if (input == null) {
                    opcion = 0;
                    break;
                }
                opcion = Integer.parseInt(input);

                switch (opcion) {
                    case 1: gestionarRegistrarPeriodo(); break; // Mantenido
                    case 2: gestionarRegistrarCurso(); break; // Mantenido
                    case 3: gestionarDefinirEvaluacion(); break; // Antes 6
                    case 4: gestionarRegistrarDocente(); break; // Antes 3
                    case 5: gestionarRegistrarSeccion(); break; // Mantenido
                    case 6: gestionarGenerarSesiones(); break; // Antes 7
                    case 7: gestionarRegistrarEstudiante(); break; // Antes 4
                    case 8: gestionarRegistroParticipacion(); break; // Antes 9
                    case 9: gestionarProcesarParticipaciones(); break; // Antes 10
                    case 10: gestionarAjusteManual(); break; // Antes 11
                    case 11: gestionarMatricula(); break; // Antes 8
                    case 0: JOptionPane.showMessageDialog(null, "Saliendo..."); break;
                    default: JOptionPane.showMessageDialog(null, "Opción no válida.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese solo números.");
            }
        } while (opcion != 0);
    }
    
    // --- GESTIÓN DE REGISTROS (MEJORA UX) ---

    private void gestionarRegistrarPeriodo() { // REFACTORIZADO A FLUJO SECUENCIAL
        int anio;
        try {
            // 1. Pedir Año y validar que sea > 2025
            String anioStr = JOptionPane.showInputDialog("Ingrese Año del Periodo Académico:");
            if (anioStr == null) return; // Usuario canceló
            anio = Integer.parseInt(anioStr);
            if (anio < 2025) {
                JOptionPane.showMessageDialog(null, "Error: El año debe ser 2025 o posterior.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Ingrese un año válido.");
            return;
        }

        // 2. Mostrar ComboBox con opciones de periodo
        String[] opcionesPeriodo = {"Verano", "Marzo", "Agosto"};
        String periodoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el periodo:",
                "Selección de Periodo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesPeriodo,
                opcionesPeriodo[0]);

        if (periodoSeleccionado == null) return; // Usuario canceló

        // 3. Generar ID temporal y validar existencia
        String idTemporal = anio + "-" + periodoSeleccionado;
        if (controlador.existePeriodo(idTemporal)) {
            JOptionPane.showMessageDialog(null, "Error: El periodo '" + idTemporal + "' ya existe.");
            return;
        }

        // 4. BLOQUE FECHA INICIO (Validación Estricta y Secuencial)
        LocalDate fechaInicio;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            String fechaInicioStr = JOptionPane.showInputDialog("Ingrese Fecha de Inicio (dd/mm/yyyy):");
            if (fechaInicioStr == null || fechaInicioStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de inicio es obligatoria.");
                return;
            }
            fechaInicio = LocalDate.parse(fechaInicioStr, formatter);
            
            if (fechaInicio.getYear() != anio) {
                JOptionPane.showMessageDialog(null, "Error: El año de la fecha de inicio (" + fechaInicio.getYear() + ") no corresponde al Año Académico indicado (" + anio + ").");
                return;
            }
            
            // NUEVA VALIDACIÓN (Fail-Fast): Verificar si la fecha de inicio ya está ocupada.
            if (controlador.fechaEstaOcupada(fechaInicio)) {
                JOptionPane.showMessageDialog(null, "Error: La fecha " + fechaInicio.format(formatter) + " ya está ocupada por otro periodo académico registrado.");
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: El formato de la fecha de inicio debe ser dd/mm/yyyy.");
            return;
        }

        // 5. BLOQUE FECHA FIN (Solo se ejecuta si el paso anterior fue exitoso)
        LocalDate fechaFin;
        try {
            String fechaFinStr = JOptionPane.showInputDialog("Ingrese Fecha de Fin (dd/mm/yyyy):");
            if (fechaFinStr == null || fechaFinStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de fin es obligatoria.");
                return;
            }
            fechaFin = LocalDate.parse(fechaFinStr, formatter);

            if (fechaFin.isBefore(fechaInicio)) {
                JOptionPane.showMessageDialog(null, "Error: La fecha de fin no puede ser anterior a la fecha de inicio.");
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: El formato de la fecha de fin debe ser dd/mm/yyyy.");
            return;
        }

        // ADVERTENCIA DE NEGOCIO: Verificar si la duración del periodo es estándar.
        long semanasReales = ChronoUnit.WEEKS.between(fechaInicio, fechaFin);
        int semanasEsperadas = periodoSeleccionado.equalsIgnoreCase("Verano") ? 9 : 18;
        long diferencia = Math.abs(semanasReales - semanasEsperadas);

        if (diferencia > 4) {
            String mensaje = "ADVERTENCIA: Ha seleccionado '" + periodoSeleccionado + "' (aprox. " + semanasEsperadas + " semanas),\n" +
                             "pero las fechas ingresadas dan una duración de " + semanasReales + " semanas.\n\n" +
                             "¿Está seguro de que desea continuar con estas fechas?";

            int respuesta = JOptionPane.showConfirmDialog(null, mensaje, "Verificación de Duración", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (respuesta != JOptionPane.YES_OPTION) {
                return; // El usuario se arrepintió, volvemos al menú para que corrija.
            }
        }

        // 6. LLAMADA FINAL (Solo si todas las validaciones pasaron)
        JOptionPane.showMessageDialog(null, controlador.registrarPeriodo(anio, periodoSeleccionado, fechaInicio, fechaFin));
    }

    private void gestionarRegistrarCurso() {
        // 1. Pedir SOLO Código primero
        String codigo = JOptionPane.showInputDialog("Ingrese Código del Curso (ej. CS101):");
        if (codigo == null || codigo.trim().isEmpty()) return;

        // 2. Validar INMEDIATAMENTE (Fail-Fast)
        if (controlador.existeCurso(codigo)) {
            JOptionPane.showMessageDialog(null, "Error: El código '" + codigo + "' ya existe en el sistema.");
            return; // Detener aquí
        }

        // 3. Pedir el resto SOLO si no existe
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Curso:");
        if (nombre == null) return;

        // 4. Usar ComboBox para seleccionar el Tipo de Curso
        String[] opcionesTipo = {"Presencial", "Remoto", "Virtual"};
        String tipoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el tipo de curso:",
                "Selección de Tipo",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcionesTipo,
                opcionesTipo[0]);

        // VALIDACIÓN: Si el usuario presiona Cancelar, el método termina.
        if (tipoSeleccionado == null) return;
        
        try {
            int capacidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese Capacidad Máxima:"));
            // Llamar al método de Controlador que ahora solo CREA
            JOptionPane.showMessageDialog(null, controlador.registrarCurso(codigo, nombre, tipoSeleccionado, capacidad));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: La capacidad debe ser número.");
        }
    }

    private void gestionarRegistrarDocente() {
        // 1. Pedir ID
        String id = JOptionPane.showInputDialog("Ingrese ID del Docente (ej. D001):");
        if (id == null || id.trim().isEmpty()) return;
        
        // 2. Validar (Fail-Fast)
        if (controlador.existeDocente(id)) {
            JOptionPane.showMessageDialog(null, "Error: El ID '" + id + "' ya existe.");
            return;
        }

        // 3. Pedir Nombre
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Docente:");
        if (nombre == null) return;
        
        JOptionPane.showMessageDialog(null, controlador.registrarDocente(id, nombre));
    }

    private void gestionarRegistrarEstudiante() {
        // PASO 1: Pedir Nombre Completo
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre Completo del Estudiante:");
        if (nombre == null || nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre es obligatorio.");
            return;
        }

        // PASO 2: Pedir Carrera
        String carrera = JOptionPane.showInputDialog("Ingrese la Carrera del Estudiante:");
        if (carrera == null || carrera.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: La carrera es obligatoria.");
            return;
        }

        // PASO C: VALIDACIÓN DE NEGOCIO (Combinación Nombre + Carrera)
        if (controlador.existeEstudiante(nombre, carrera)) {
            JOptionPane.showMessageDialog(null, "Error: El estudiante '" + nombre.trim() + "' ya está registrado en la carrera de '" + carrera.trim() + "'.");
            return;
        }

        // PASO 3: Pedir Ciclo (Solo si las validaciones anteriores pasaron)
        int ciclo;
        try {
            String cicloStr = JOptionPane.showInputDialog("Ingrese el Ciclo del Estudiante (1-12):");
            ciclo = Integer.parseInt(cicloStr);
            if (ciclo < 1 || ciclo > 12) {
                JOptionPane.showMessageDialog(null, "Error: El ciclo debe estar entre 1 y 12.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: El ciclo debe ser un número válido.");
            return;
        }

        // FINAL: Llamar al controlador solo si todas las validaciones pasaron
        JOptionPane.showMessageDialog(null, controlador.registrarEstudiante(nombre, carrera, ciclo));
    }
    
    private void gestionarRegistrarSeccion() {
        // 1. Pedir y validar el Código del Curso
        String codigoCurso = JOptionPane.showInputDialog("Ingrese Código del Curso:");
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return;
        if (!controlador.existeCurso(codigoCurso)) {
            JOptionPane.showMessageDialog(null, "Error: El curso con código '" + codigoCurso + "' no existe. Regístrelo primero.");
            return;
        }
        
        // 2. Pedir y validar el ID del Docente
        String idDocente = JOptionPane.showInputDialog("Ingrese ID del Docente:");
        if (idDocente == null || idDocente.trim().isEmpty()) return;
        if (!controlador.existeDocente(idDocente)) {
            JOptionPane.showMessageDialog(null, "Error: El docente con ID '" + idDocente + "' no existe. Regístrelo primero.");
            return;
        }

        // 3. Obtener y mostrar los periodos disponibles en un ComboBox
        ArrayList<String> idsPeriodos = controlador.obtenerIDsPeriodos();
        if (idsPeriodos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: No hay periodos académicos registrados. Por favor, registre un periodo primero.");
            return;
        }

        String periodoSeleccionado = (String) JOptionPane.showInputDialog(
                null,
                "Seleccione el Periodo Académico:",
                "Registro de Sección",
                JOptionPane.QUESTION_MESSAGE,
                null,
                idsPeriodos.toArray(), // Convertir ArrayList a Array
                idsPeriodos.get(0)
        );

        if (periodoSeleccionado == null) {
            return; // El usuario canceló la selección
        }

        // 4. Llamar al controlador con el periodo seleccionado
        JOptionPane.showMessageDialog(null, controlador.registrarSeccion(codigoCurso, idDocente, periodoSeleccionado));
    }
    
    // --- GESTIÓN DE PROCESOS (Sin cambios en lógica) ---
    
    private void gestionarGenerarSesiones() {
        // 1. Pedir y validar ID de Sección (Fail-Fast)
        String idSec = JOptionPane.showInputDialog("Ingrese ID de la Sección:");
        if (idSec == null || idSec.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El ID de la sección es obligatorio.");
            return;
        }
        if (!controlador.existeSeccion(idSec)) {
            JOptionPane.showMessageDialog(null, "Error: La sección con ID '" + idSec + "' no existe.");
            return;
        }
        
        // 2. Pedir días de la semana (La fecha de inicio ya no se pide)
        String diasStr = JOptionPane.showInputDialog("Ingrese los días de clase separados por coma (ej. LUNES,MIERCOLES):");
        if (diasStr == null || diasStr.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Debe ingresar al menos un día de clase.");
            return;
        }

        // 3. Procesar días y llamar al controlador
        ArrayList<DayOfWeek> diasList = new ArrayList<>();
        for (String d : diasStr.split(",")) {
            DayOfWeek dia = traducirDia(d);
            if (dia != null) diasList.add(dia);
        }
        
        try {
            mostrarScroll(controlador.generarSesiones(idSec, diasList.toArray(new DayOfWeek[0])), "Calendario de Sesiones Generado");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error inesperado al generar las sesiones: " + e.getMessage());
        }
    }

    private void gestionarMatricula() {
        // PASO 1: Pedir y validar ID de Sección
        String idSeccion = JOptionPane.showInputDialog("Ingrese el ID de la Sección:");
        if (idSeccion == null) return; // Cancelado
        if (idSeccion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El ID de la sección es obligatorio.");
            return;
        }
        if (!controlador.existeSeccion(idSeccion)) {
            JOptionPane.showMessageDialog(null, "Error: La sección con ID '" + idSeccion + "' no existe.");
            return;
        }

        // PASO 2: Pedir y validar Código de Estudiante
        String codigoEstudiante = JOptionPane.showInputDialog("Ingrese el Código del Estudiante:");
        if (codigoEstudiante == null) return; // Cancelado
        if (codigoEstudiante.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El código del estudiante es obligatorio.");
            return;
        }
        if (!controlador.existeEstudiantePorCodigo(codigoEstudiante)) {
            JOptionPane.showMessageDialog(null, "Error: El estudiante con código '" + codigoEstudiante + "' no existe.");
            return;
        }

        // FINAL: Llamar al controlador
        JOptionPane.showMessageDialog(null, controlador.matricularEstudiante(codigoEstudiante, idSeccion));
    }

    private void gestionarRegistroParticipacion() {
        // PASO 1: Pedir y validar ID Sección
        String idSeccion = JOptionPane.showInputDialog("Ingrese el ID de la Sección:");
        if (idSeccion == null) return; // Cancelado
        if (idSeccion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El ID de la sección es obligatorio.");
            return;
        }
        if (!controlador.existeSeccion(idSeccion)) {
            JOptionPane.showMessageDialog(null, "Error: La sección con ID '" + idSeccion + "' no existe.");
            return;
        }

        // PASO 2: Pedir y validar Código Estudiante
        String codigoEstudiante = JOptionPane.showInputDialog("Ingrese el Código del Estudiante a registrar participación:");
        if (codigoEstudiante == null) return; // Cancelado
        if (codigoEstudiante.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El código del estudiante es obligatorio.");
            return;
        }
        if (!controlador.estaMatriculado(idSeccion, codigoEstudiante)) {
            JOptionPane.showMessageDialog(null, "Error: El estudiante con código '" + codigoEstudiante + "' no está matriculado en esta sección.");
            return;
        }

        // PASO 3: Pedir y validar Evaluación
        String nombreEvaluacion = JOptionPane.showInputDialog("Ingrese el nombre de la Evaluación (ej. PC1):");
        if (nombreEvaluacion == null) return; // Cancelado
        if (nombreEvaluacion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: El nombre de la evaluación es obligatorio.");
            return;
        }
        if (!controlador.existeEvaluacionEnCurso(idSeccion, nombreEvaluacion)) {
            JOptionPane.showMessageDialog(null, "Error: La evaluación '" + nombreEvaluacion + "' no está definida en el curso de esta sección.");
            return;
        }

        // PASO 4: Pedir y validar Semana
        int semanaNum;
        try {
            String semanaStr = JOptionPane.showInputDialog("Ingrese el número de la Semana (ej. 1):");
            if (semanaStr == null) return; // Cancelado
            semanaNum = Integer.parseInt(semanaStr);
            if (semanaNum <= 0) {
                JOptionPane.showMessageDialog(null, "Error: El número de semana debe ser positivo.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Ingrese un número de semana válido.");
            return;
        }

        // PASO 5: Seleccionar Sesión (Lógica inteligente)
        ArrayList<String> sesionesFiltradas = controlador.obtenerSesionesPorSemana(idSeccion, semanaNum);
        String sesionSeleccionada;

        if (sesionesFiltradas.isEmpty()) {
            // CASO A: Lista vacía
            JOptionPane.showMessageDialog(null, "Error: No hay sesiones registradas en la semana " + semanaNum + " (o es feriado).");
            return;
        } else if (sesionesFiltradas.size() == 1) {
            // CASO B: Sesión única
            sesionSeleccionada = sesionesFiltradas.get(0);
            JOptionPane.showMessageDialog(null, "Sesión única detectada: " + sesionSeleccionada + ". Seleccionada automáticamente.");
        } else {
            // CASO C: Múltiples sesiones, mostrar ComboBox
            sesionSeleccionada = (String) JOptionPane.showInputDialog(null, "Seleccione la fecha de la sesión para la semana " + semanaNum + ":",
                    "Selección de Sesión", JOptionPane.QUESTION_MESSAGE, null, sesionesFiltradas.toArray(), sesionesFiltradas.get(0));
            if (sesionSeleccionada == null) return; // Cancelado
        }

        // FINAL: Llamar al controlador con todos los datos validados
        JOptionPane.showMessageDialog(null, controlador.registrarParticipacion(idSeccion, nombreEvaluacion, "Semana " + semanaNum, sesionSeleccionada, codigoEstudiante));
    }

    private void gestionarProcesarParticipaciones() {
        String sec = JOptionPane.showInputDialog("ID Sección:");
        String eval = JOptionPane.showInputDialog("Evaluación:");
        if (sec != null && eval != null) {
            mostrarScroll(controlador.procesarParticipaciones(sec, eval), "Resultado");
        }
    }

    private void gestionarDefinirEvaluacion() {
        // PASO 1: Pedir el "Código del Curso"
        String codigoCurso = JOptionPane.showInputDialog("Ingrese Código del Curso:");

        // VALIDACIÓN 1: Campo vacío
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) {
            // No se muestra mensaje si el usuario presiona cancelar, solo si deja el campo vacío.
            if (codigoCurso != null) JOptionPane.showMessageDialog(null, "Error: El campo Código del Curso no puede estar vacío.");
            return;
        }

        // VALIDACIÓN 2: Verificar si el curso existe (Fail-Fast)
        if (!controlador.existeCurso(codigoCurso)) {
            JOptionPane.showMessageDialog(null, "Error: El curso con código '" + codigoCurso + "' no existe. Regístrelo primero.");
            return;
        }

        // PASO 2: Recién ahora, pedir el "Nombre de la Evaluación"
        String nombreEvaluacion = JOptionPane.showInputDialog("Ingrese Nombre de la Evaluación (ej. PC1):");
        // VALIDACIÓN: Asegurar que el campo no esté vacío o cancelado
        if (nombreEvaluacion == null || nombreEvaluacion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Campo vacío.");
            return;
        }

        // FINAL: Llamar al controlador para guardar la evaluación
        JOptionPane.showMessageDialog(null, controlador.definirEvaluacion(codigoCurso, nombreEvaluacion));
    }

    private void gestionarAjusteManual() {
        String sec = JOptionPane.showInputDialog("ID Sección:");
        String eval = JOptionPane.showInputDialog("Evaluación:");
        String cod = JOptionPane.showInputDialog("Código Estudiante:");
        String pts = JOptionPane.showInputDialog("Nuevo Puntaje:");
        try {
            JOptionPane.showMessageDialog(null, controlador.ajustarParticipaciones(sec, eval, cod, Integer.parseInt(pts)));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en puntaje.");
        }
    }
    
    private void mostrarScroll(String texto, String titulo) {
        javax.swing.JTextArea ta = new javax.swing.JTextArea(texto);
        ta.setEditable(false);
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(ta);
        sp.setPreferredSize(new java.awt.Dimension(500, 400));
        JOptionPane.showMessageDialog(null, sp, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
}