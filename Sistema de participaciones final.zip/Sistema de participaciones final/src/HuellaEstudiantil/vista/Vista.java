package HuellaEstudiantil.vista;

import HuellaEstudiantil.controlador.Controlador;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Vista {

    private Controlador controlador;

    public Vista() {
        this.controlador = new Controlador();
    }
    
    private DayOfWeek traducirDia(String diaEnEspanol) {
        switch (diaEnEspanol.trim().toUpperCase()) {
            case "LUNES": return DayOfWeek.MONDAY;
            case "MARTES": return DayOfWeek.TUESDAY;
            case "MIERCOLES":
            case "MIÉRCOLES": return DayOfWeek.WEDNESDAY;
            case "JUEVES": return DayOfWeek.THURSDAY;
            case "VIERNES": return DayOfWeek.FRIDAY;
            case "SABADO":
            case "SÁBADO": return DayOfWeek.SATURDAY;
            case "DOMINGO": return DayOfWeek.SUNDAY;
            default: return null; 
        }
    }

    public void mostrarMenu() {
        String menu = "SISTEMA DE PARTICIPACIONES 'HUELLA ESTUDIANTIL'\n\n"
                + "--- MÓDULO DE CONFIGURACIÓN ---\n"
                + "1. Registrar Curso\n"
                + "2. Registrar Docente\n"
                + "3. Registrar Sección\n"
                + "4. Definir Estructura de Evaluaciones por Curso\n"
                + "5. Generar Sesiones de Clase\n\n"
                + "--- MÓDULO DE GESTIÓN DE CLASE ---\n"
                + "6. Registrar Estudiante\n"
                + "7. Registrar Participación\n"
                + "8. Procesar Participaciones\n"
                + "9. Ajustar Puntos Manualmente\n\n"
                + "--- MÓDULO DE ADMINISTRACIÓN Y CALIFICACIONES ---\n"
                + "10. Matricular Estudiante en Sección\n\n"
                + "0. Salir\n\n"
                + "Ingrese una opción:";

        int opcion = -1;
        do {
            try {
                String input = JOptionPane.showInputDialog(null, menu);
                if (input == null) {
                    opcion = 0;
                    break;
                }
                opcion = Integer.parseInt(input);

                switch (opcion) {
                    case 1: gestionarRegistrarCurso(); break;
                    case 2: gestionarRegistrarDocente(); break;
                    case 3: gestionarRegistrarSeccion(); break;
                    case 4: gestionarDefinirEvaluacion(); break;
                    case 5: gestionarGenerarSesiones(); break;
                    case 6: gestionarRegistrarEstudiante(); break;
                    case 7: gestionarRegistroParticipacion(); break;
                    case 8: gestionarProcesarParticipaciones(); break;
                    case 9: gestionarAjusteManual(); break;
                    case 10: gestionarMatricula(); break;
                    case 0: JOptionPane.showMessageDialog(null, "Saliendo..."); break;
                    default: JOptionPane.showMessageDialog(null, "Opción no válida.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese solo números.");
            }
        } while (opcion != 0);
    }
    
    // --- GESTIÓN DE REGISTROS (MEJORA UX) ---

    private void gestionarRegistrarCurso() {
        // 1. Pedir SOLO Código primero
        String codigo = JOptionPane.showInputDialog("Ingrese Código del Curso (ej. CS101):");
        if (codigo == null || codigo.trim().isEmpty()) return;

        // 2. Validar INMEDIATAMENTE (Fail-Fast)
        if (controlador.existeCurso(codigo)) {
            JOptionPane.showMessageDialog(null, "Error: El código '" + codigo + "' ya existe en el sistema.");
            return; // Detener aquí
        }

        // 3. Pedir el resto SOLO si no existe
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Curso:");
        if (nombre == null) return;
        String tipo = JOptionPane.showInputDialog("Ingrese Tipo (Presencial/Remoto):");
        if (tipo == null) return;
        
        try {
            int capacidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese Capacidad Máxima:"));
            // Llamar al método de Controlador que ahora solo CREA
            JOptionPane.showMessageDialog(null, controlador.registrarCurso(codigo, nombre, tipo, capacidad));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: La capacidad debe ser número.");
        }
    }

    private void gestionarRegistrarDocente() {
        // 1. Pedir ID
        String id = JOptionPane.showInputDialog("Ingrese ID del Docente (ej. D001):");
        if (id == null || id.trim().isEmpty()) return;
        
        // 2. Validar (Fail-Fast)
        if (controlador.existeDocente(id)) {
            JOptionPane.showMessageDialog(null, "Error: El ID '" + id + "' ya existe.");
            return;
        }

        // 3. Pedir Nombre
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre del Docente:");
        if (nombre == null) return;
        
        JOptionPane.showMessageDialog(null, controlador.registrarDocente(id, nombre));
    }

    private void gestionarRegistrarEstudiante() {
        // Aquí generamos código auto, así que solo pedimos datos
        String nombre = JOptionPane.showInputDialog("Ingrese Nombre Completo:");
        if (nombre == null) return;
        
        String carrera = JOptionPane.showInputDialog("Ingrese Carrera (Sistemas/Software):");
        if (carrera == null) return;
        
        try {
            int ciclo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese Ciclo (1-12):"));
            JOptionPane.showMessageDialog(null, controlador.registrarEstudiante(nombre, carrera, ciclo));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Ciclo inválido.");
        }
    }
    
    private void gestionarRegistrarSeccion() {
        // 1. Pedir y validar el Código del Curso
        String codigoCurso = JOptionPane.showInputDialog("Ingrese Código del Curso:");
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return;
        if (!controlador.existeCurso(codigoCurso)) {
            JOptionPane.showMessageDialog(null, "Error: El curso con código '" + codigoCurso + "' no existe. Regístrelo primero.");
            return;
        }
        
        // 2. Pedir y validar el ID del Docente
        String idDocente = JOptionPane.showInputDialog("Ingrese ID del Docente:");
        if (idDocente == null || idDocente.trim().isEmpty()) return;
        if (!controlador.existeDocente(idDocente)) {
            JOptionPane.showMessageDialog(null, "Error: El docente con ID '" + idDocente + "' no existe. Regístrelo primero.");
            return;
        }

        // 3. Pedir el resto de datos
        String periodo = JOptionPane.showInputDialog("Ingrese Periodo (ej. 2025-Marzo):");
        if (periodo == null) return;

        JOptionPane.showMessageDialog(null, controlador.registrarSeccion(codigoCurso, idDocente, periodo));
    }
    
    // --- GESTIÓN DE PROCESOS (Sin cambios en lógica) ---
    
    private void gestionarGenerarSesiones() {
        String idSec = JOptionPane.showInputDialog("Ingrese ID Sección:");
        if (idSec == null) return;
        String fechaStr = JOptionPane.showInputDialog("Fecha Inicio (dd/MM/yyyy):");
        if (fechaStr == null) return;
        
        try {
            String[] partes = fechaStr.split("/");
            LocalDate fecha = LocalDate.of(Integer.parseInt(partes[2]), Integer.parseInt(partes[1]), Integer.parseInt(partes[0]));
            
            String diasStr = JOptionPane.showInputDialog("Días (ej. LUNES,VIERNES):");
            if (diasStr == null) return;
            
            ArrayList<DayOfWeek> diasList = new ArrayList<>();
            for(String d : diasStr.split(",")) {
                DayOfWeek dia = traducirDia(d);
                if(dia != null) diasList.add(dia);
            }
            mostrarScroll(controlador.generarSesiones(idSec, fecha, diasList.toArray(new DayOfWeek[0])), "Calendario");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Error en fecha.");
        }
    }

    private void gestionarMatricula() {
        String cod = JOptionPane.showInputDialog("Código Estudiante:");
        String sec = JOptionPane.showInputDialog("ID Sección:");
        if (cod != null && sec != null) {
            JOptionPane.showMessageDialog(null, controlador.matricularEstudiante(cod, sec));
        }
    }

    private void gestionarRegistroParticipacion() {
        String sec = JOptionPane.showInputDialog("ID Sección:");
        String eval = JOptionPane.showInputDialog("Evaluación (PC1):");
        String sem = JOptionPane.showInputDialog("Semana:");
        String ses = JOptionPane.showInputDialog("Sesión:");
        String cod = JOptionPane.showInputDialog("Código Estudiante:");
        
        if (cod != null) {
            JOptionPane.showMessageDialog(null, controlador.registrarParticipacion(sec, eval, sem, ses, cod));
        }
    }

    private void gestionarProcesarParticipaciones() {
        String sec = JOptionPane.showInputDialog("ID Sección:");
        String eval = JOptionPane.showInputDialog("Evaluación:");
        if (sec != null && eval != null) {
            mostrarScroll(controlador.procesarParticipaciones(sec, eval), "Resultado");
        }
    }

    private void gestionarDefinirEvaluacion() {
        // PASO 1: Pedir el "Código del Curso"
        String codigoCurso = JOptionPane.showInputDialog("Ingrese Código del Curso:");

        // VALIDACIÓN 1: Campo vacío
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) {
            // No se muestra mensaje si el usuario presiona cancelar, solo si deja el campo vacío.
            if (codigoCurso != null) JOptionPane.showMessageDialog(null, "Error: El campo Código del Curso no puede estar vacío.");
            return;
        }

        // VALIDACIÓN 2: Verificar si el curso existe (Fail-Fast)
        if (!controlador.existeCurso(codigoCurso)) {
            JOptionPane.showMessageDialog(null, "Error: El curso con código '" + codigoCurso + "' no existe. Regístrelo primero.");
            return;
        }

        // PASO 2: Recién ahora, pedir el "Nombre de la Evaluación"
        String nombreEvaluacion = JOptionPane.showInputDialog("Ingrese Nombre de la Evaluación (ej. PC1):");
        // VALIDACIÓN: Asegurar que el campo no esté vacío o cancelado
        if (nombreEvaluacion == null || nombreEvaluacion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Campo vacío.");
            return;
        }

        // FINAL: Llamar al controlador para guardar la evaluación
        JOptionPane.showMessageDialog(null, controlador.definirEvaluacion(codigoCurso, nombreEvaluacion));
    }

    private void gestionarAjusteManual() {
        String sec = JOptionPane.showInputDialog("ID Sección:");
        String eval = JOptionPane.showInputDialog("Evaluación:");
        String cod = JOptionPane.showInputDialog("Código Estudiante:");
        String pts = JOptionPane.showInputDialog("Nuevo Puntaje:");
        try {
            JOptionPane.showMessageDialog(null, controlador.ajustarParticipaciones(sec, eval, cod, Integer.parseInt(pts)));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error en puntaje.");
        }
    }
    
    private void mostrarScroll(String texto, String titulo) {
        javax.swing.JTextArea ta = new javax.swing.JTextArea(texto);
        ta.setEditable(false);
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(ta);
        sp.setPreferredSize(new java.awt.Dimension(500, 400));
        JOptionPane.showMessageDialog(null, sp, titulo, JOptionPane.INFORMATION_MESSAGE);
    }
}