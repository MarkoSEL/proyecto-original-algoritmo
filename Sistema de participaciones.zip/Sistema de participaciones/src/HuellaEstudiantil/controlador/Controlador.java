package HuellaEstudiantil.controlador;

import HuellaEstudiantil.datos.BaseDeDatos;
import HuellaEstudiantil.modelo.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;

public class Controlador {

    private BaseDeDatos db;

    public Controlador() {
        this.db = BaseDeDatos.getInstancia();
    }

    // --- MÉTODOS DE VALIDACIÓN RÁPIDA (UX) ---
    public boolean existeCurso(String codigo) {
        return db.buscarCursoPorCodigo(codigo) != null;
    }

    public boolean existeDocente(String id) {
        return db.buscarDocentePorId(id) != null;
    }
    
    // --- 1. REGISTRAR CURSO (Refactorizado) ---
    public String registrarCurso(String codigo, String nombre, String tipo, int capacidad) {
        if (existeCurso(codigo)) {
            return "Error: El código '" + codigo + "' ya existe en el sistema.";
        }
        
        NodoCurso nuevoCurso = new NodoCurso(codigo, nombre, tipo, capacidad);
        db.listaCursos.agregarAlFinal(nuevoCurso);
        
        return "Curso registrado exitosamente.\n" +
               "Código: " + codigo + "\n" +
               "Nombre: " + nombre;
    }

    // --- 2. REGISTRAR DOCENTE (Refactorizado) ---
    public String registrarDocente(String id, String nombre) {
        if (existeDocente(id)) {
            return "Error: El ID de docente '" + id + "' ya existe.";
        }
        
        NodoDocente nuevoDocente = new NodoDocente(id, nombre);
        db.listaDocentes.agregarAlFinal(nuevoDocente);
        
        return "Docente registrado exitosamente.\n" +
               "ID: " + id + "\n" +
               "Nombre: " + nombre;
    }

    // --- 3. REGISTRAR ESTUDIANTE (Con generación automática de código) ---
    public String registrarEstudiante(String nombre, String carrera, int ciclo) {
        // Generación de código simple: U2025 + contador
        int cantidadActual = db.listaEstudiantes.getTodosComoArrayList().size();
        String nuevoCodigo = "U2025" + String.format("%03d", cantidadActual + 1);
        
        NodoEstudiante nuevoEst = new NodoEstudiante(nuevoCodigo, nombre, carrera, ciclo);
        db.listaEstudiantes.agregarAlFinal(nuevoEst);
        
        return "Estudiante registrado exitosamente.\n" +
               "Código Generado: " + nuevoCodigo + "\n" +
               "Nombre: " + nombre;
    }

    // --- 4. REGISTRAR SECCIÓN (Refactorizado) ---
    public String registrarSeccion(String codigoCurso, String idDocente, String periodo) {
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: El curso no existe.";
        
        NodoDocente docente = db.buscarDocentePorId(idDocente);
        if (docente == null) return "Error: El docente no existe.";
        
        // Generar ID único simple para la sección
        String idSeccion = curso.getCodigo() + "-SEC" + (int)(Math.random() * 1000);
        
        NodoSeccion nuevaSeccion = new NodoSeccion(idSeccion, curso, docente, periodo);
        db.listaSecciones.agregarAlFinal(nuevaSeccion);
        
        return "Sección creada exitosamente.\n" +
               "ID Generado: " + idSeccion + "\n" +
               "Curso: " + curso.getNombre() + "\n" +
               "Docente: " + docente.getNombre();
    }
    
    // --- 5. DEFINIR EVALUACIÓN ---
    public String definirEvaluacion(String codigoCurso, String nombreEvaluacion) {
        if (codigoCurso == null || codigoCurso.trim().isEmpty()) return "Error: Código vacío.";
        NodoCurso curso = db.buscarCursoPorCodigo(codigoCurso);
        if (curso == null) return "Error: Curso no existe.";
        
        for (String eval : curso.getEstructuraEvaluaciones()) {
            if (eval.equalsIgnoreCase(nombreEvaluacion.trim())) return "Error: Evaluación ya existe.";
        }
        curso.agregarEvaluacion(nombreEvaluacion.trim());
        return "Evaluación agregada exitosamente.";
    }

    // --- 6. GENERAR SESIONES ---
    private HashSet<LocalDate> obtenerFeriados() {
        HashSet<LocalDate> feriados = new HashSet<>();
        feriados.add(LocalDate.of(2025, 3, 25)); 
        feriados.add(LocalDate.of(2025, 5, 1));
        feriados.add(LocalDate.of(2025, 7, 28));
        feriados.add(LocalDate.of(2025, 7, 29));
        feriados.add(LocalDate.of(2025, 8, 30));
        feriados.add(LocalDate.of(2025, 10, 8));
        feriados.add(LocalDate.of(2025, 11, 1));
        feriados.add(LocalDate.of(2025, 12, 8));
        feriados.add(LocalDate.of(2025, 12, 25));
        return feriados;
    }
    
    private boolean esFeriado(LocalDate fecha, HashSet<LocalDate> feriados) {
        return feriados.contains(fecha);
    }
    
    public String generarSesiones(String idSeccion, LocalDate fechaInicio, DayOfWeek... dias) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        if (fechaInicio == null) return "Error: No se ingresó la fecha de inicio.";
        if (dias == null || dias.length == 0) return "Error: No se ingresaron los días de la semana.";
        
        seccion.getSesionesDeClase().clear();
        
        String periodo = seccion.getPeriodo().toLowerCase();
        int totalSesiones = periodo.contains("verano") ? 9 : 18;
        
        HashSet<LocalDate> feriados = obtenerFeriados();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        StringBuilder resultado = new StringBuilder();
        resultado.append("SESIONES DE CLASE GENERADAS\n============================\n");
        resultado.append("Sección: ").append(seccion.getId()).append("\n");
        resultado.append("Fecha de inicio: ").append(fechaInicio.format(formatoFecha)).append("\n");
        
        int numeroSesion = 1;
        LocalDate fechaActual = fechaInicio;
        int semanas = 0;
        
        while (numeroSesion <= totalSesiones) {
            for (DayOfWeek dia : dias) {
                if (numeroSesion > totalSesiones) break;
                int diasHastaDia = dia.getValue() - fechaActual.getDayOfWeek().getValue();
                if (diasHastaDia < 0) diasHastaDia += 7;
                LocalDate fechaSesion = fechaActual.plusDays(diasHastaDia);
                seccion.getSesionesDeClase().add(fechaSesion);
                
                if (esFeriado(fechaSesion, feriados)) {
                    resultado.append(String.format("Sesión %02d: A reprogramar %s\n", numeroSesion++, fechaSesion.format(formatoFecha)));
                } else {
                    String diaNombre = fechaSesion.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.of("es", "ES"));
                    resultado.append(String.format("Sesión %02d: %s %s\n", numeroSesion++, diaNombre, fechaSesion.format(formatoFecha)));
                }
            }
            semanas++;
            fechaActual = fechaInicio.plusWeeks(semanas);
        }
        return resultado.toString();
    }

    // --- 7. MATRICULAR ESTUDIANTE ---
    public String matricularEstudiante(String codigoEstudiante, String idSeccion) {
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El código de estudiante no se encuentra.";
        
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                return "Error: El estudiante ya se encuentra matriculado en esta sección.";
            }
        }
        
        int capacidadMaxima = seccion.getCurso().getCapacidadMaxima();
        if (seccion.getEstudiantesMatriculados().size() >= capacidadMaxima) {
            return "Error: La sección ha alcanzado su capacidad máxima.";
        }
        
        seccion.matricularEstudiante(estudiante);
        return "Estudiante matriculado exitosamente.";
    }
    
    // --- 8. REGISTRAR PARTICIPACIÓN ---
    public String registrarParticipacion(String idSeccion, String idEvaluacion, String semana, String sesion, String codigoEstudiante) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: El ID de sección no se encuentra.";
        
        NodoEstudiante estudiante = db.buscarEstudiantePorCodigo(codigoEstudiante);
        if (estudiante == null) return "Error: El código de estudiante no se encuentra.";
        
        boolean estaMatriculado = false;
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                estaMatriculado = true;
                break;
            }
        }
        if (!estaMatriculado) return "Error: El estudiante no está matriculado en esta sección.";
        
        int participacionesActuales = seccion.obtenerParticipacionesPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        if (participacionesActuales >= 4) {
            return "Error: El estudiante ya ha alcanzado el límite de 4 participaciones para esta sesión/evaluación.";
        }
        
        seccion.incrementarParticipacionPorSesionEvaluacion(codigoEstudiante, sesion, idEvaluacion);
        estudiante.incrementarParticipacion();
        
        return "Participación registrada. Total actual: " + (participacionesActuales + 1);
    }
    
    // --- 9. PROCESAR PARTICIPACIONES ---
    private void ordenamientoBurbuja(ArrayList<NodoEstudiante> lista) {
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (lista.get(j).getParticipaciones() < lista.get(j + 1).getParticipaciones()) {
                    NodoEstudiante aux = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j + 1, aux);
                }
            }
        }
    }
    
    public String procesarParticipaciones(String idSeccion, String idEvaluacion) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: La sección no existe.";
        
        if (seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) {
            return "Error: La evaluación ya ha sido procesada.";
        }

        ArrayList<NodoEstudiante> participantes = new ArrayList<>();
        for (NodoEstudiante e : seccion.getEstudiantesMatriculados()) {
            if (e.getParticipaciones() > 0) participantes.add(e);
        }

        if (participantes.isEmpty()) return "No hay estudiantes con participaciones para procesar.";
        
        ordenamientoBurbuja(participantes);
        
        StringBuilder resultado = new StringBuilder("PROCESAMIENTO DE PARTICIPACIONES\n");
        int puntosDisponibles = 3;
        int participacionesAnteriores = -1;
        
        for (int i = 0; i < participantes.size(); i++) {
            NodoEstudiante estudiante = participantes.get(i);
            int participacionesActuales = estudiante.getParticipaciones();
            
            if (participacionesActuales != participacionesAnteriores) {
                if (i == 0) puntosDisponibles = 3;
                else if (i == 1) puntosDisponibles = 2;
                else puntosDisponibles = 1;
            }
            
            seccion.asignarPuntos(estudiante.getCodigo(), idEvaluacion, puntosDisponibles);
            resultado.append(String.format("%s (%d part) -> %d puntos\n", estudiante.getNombre(), participacionesActuales, puntosDisponibles));
            participacionesAnteriores = participacionesActuales;
            estudiante.setParticipaciones(0);
        }
        
        seccion.getEvaluacionesProcesadas().add(idEvaluacion.toUpperCase());
        return resultado.toString();
    }

    // --- 10. AJUSTAR MANUALMENTE ---
    public String ajustarParticipaciones(String idSeccion, String idEvaluacion, String codigoEstudiante, int nuevoPuntaje) {
        NodoSeccion seccion = db.buscarSeccionPorId(idSeccion);
        if (seccion == null) return "Error: Sección no existe.";
        
        if (!seccion.getEvaluacionesProcesadas().contains(idEvaluacion.toUpperCase())) return "Error: Evaluación no procesada.";
        
        seccion.asignarPuntos(codigoEstudiante, idEvaluacion, nuevoPuntaje);
        return "Ajuste realizado correctamente.";
    }
}